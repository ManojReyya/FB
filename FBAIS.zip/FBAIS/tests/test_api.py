import json


class TestProfitAPI:
    """Test profit prediction API endpoints"""

    def test_restaurant_config_endpoint(self, client):
        """Test restaurant configuration endpoint"""
        response = client.get("/api/restaurant-config")

        assert response.status_code == 200
        data = json.loads(response.data)
        assert "cities" in data
        assert "cuisines" in data
        assert "location_types" in data
        assert isinstance(data["cities"], list)
        assert len(data["cities"]) > 0

    def test_predict_profit_success(self, auth_client, sample_restaurant_data):
        """Test successful profit prediction"""
        response = auth_client.post("/api/predict-profit", json=sample_restaurant_data)

        if response.status_code == 200:
            data = json.loads(response.data)
            assert data["success"] is True
            assert "prediction" in data
            assert "predicted_profit" in data["prediction"]

    def test_predict_profit_invalid_data(self, auth_client):
        """Test profit prediction with invalid data"""
        response = auth_client.post("/api/predict-profit", json={"city": "InvalidCity"})

        assert response.status_code in [400, 500]


class TestInventoryAPI:
    """Test inventory/recipe API endpoints"""

    def test_search_recipes(self, auth_client):
        """Test recipe search endpoint"""
        response = auth_client.get("/api/search-recipes?q=chicken")

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data

    def test_get_recipe_stats(self, auth_client):
        """Test recipe statistics endpoint"""
        response = auth_client.get("/api/recipe-stats")

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data


class TestWasteAPI:
    """Test waste tracking API endpoints"""

    def test_get_waste_categories(self, auth_client):
        """Test get waste categories endpoint"""
        response = auth_client.get("/api/waste-categories")

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data or isinstance(data, list)

    def test_add_waste_entry(self, auth_client):
        """Test adding waste entry"""
        response = auth_client.post(
            "/api/waste-entries",
            json={
                "item_name": "Tomatoes",
                "category": "Vegetables",
                "quantity": 2.5,
                "unit": "kg",
                "cost_value": 100,
                "date_recorded": "2024-01-01",
                "notes": "Expired",
            },
        )

        if response.status_code == 200:
            data = json.loads(response.data)
            assert data["success"] is True

    def test_get_waste_entries(self, auth_client):
        """Test getting waste entries"""
        response = auth_client.get("/api/waste-entries")

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data or isinstance(data, list)

    def test_get_waste_analytics(self, auth_client):
        """Test waste analytics endpoint"""
        response = auth_client.get("/api/waste-analytics")

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data or "total_waste_cost" in data


class TestCustomerPersonaAPI:
    """Test customer persona API endpoints"""

    def test_identify_persona(self, auth_client, sample_customer_data):
        """Test persona identification endpoint"""
        response = auth_client.post("/api/identify-persona", json=sample_customer_data)

        if response.status_code == 200:
            data = json.loads(response.data)
            assert data["success"] is True
            assert "persona" in data

    def test_get_all_personas(self, auth_client):
        """Test get all personas endpoint"""
        response = auth_client.get("/api/personas")

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data or isinstance(data, dict)

    def test_identify_persona_missing_fields(self, auth_client):
        """Test persona identification with missing fields"""
        response = auth_client.post("/api/identify-persona", json={"time": 12})

        if response.status_code == 200:
            data = json.loads(response.data)
            assert "success" in data or "persona" in data


class TestAPIValidation:
    """Test API input validation"""

    def test_json_content_type_required(self, auth_client):
        """Test that JSON content type is handled properly"""
        response = auth_client.post("/api/predict-profit", data="not json")

        assert response.status_code in [400, 500]

    def test_empty_request_handling(self, auth_client):
        """Test empty request handling"""
        response = auth_client.post("/api/predict-profit", json={})

        assert response.status_code in [400, 500]
