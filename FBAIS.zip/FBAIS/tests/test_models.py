import pytest
import os
import sys
import pickle

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


class TestModelFiles:
    """Test that model files exist and are loadable"""

    def test_profit_model_exists(self):
        """Test that profit model file exists"""
        model_path = "machine_learning/profitability_models/profit_model.pkl"

        if os.path.exists(model_path):
            assert os.path.isfile(model_path)
            assert os.path.getsize(model_path) > 0
        else:
            pytest.skip("Profit model not trained yet")

    def test_risk_model_exists(self):
        """Test that risk model file exists"""
        model_path = "machine_learning/profitability_models/risk_model.pkl"

        if os.path.exists(model_path):
            assert os.path.isfile(model_path)
            assert os.path.getsize(model_path) > 0
        else:
            pytest.skip("Risk model not trained yet")

    def test_scaler_exists(self):
        """Test that scaler file exists"""
        scaler_path = "machine_learning/profitability_models/scaler.pkl"

        if os.path.exists(scaler_path):
            assert os.path.isfile(scaler_path)
        else:
            pytest.skip("Scaler not trained yet")

    def test_encoders_exist(self):
        """Test that label encoders file exists"""
        encoders_path = "machine_learning/profitability_models/label_encoders.pkl"

        if os.path.exists(encoders_path):
            assert os.path.isfile(encoders_path)
        else:
            pytest.skip("Encoders not trained yet")


@pytest.mark.skipif(
    not os.path.exists("machine_learning/profitability_models/profit_model.pkl"),
    reason="ML models not trained yet",
)
class TestModelLoading:
    """Test model loading functionality"""

    def test_load_profit_model(self):
        """Test loading profit prediction model"""
        model_path = "machine_learning/profitability_models/profit_model.pkl"

        try:
            with open(model_path, "rb") as f:
                model = pickle.load(f)

            assert model is not None
            assert hasattr(model, "predict")
        except Exception as e:
            pytest.fail(f"Failed to load profit model: {e}")

    def test_load_risk_model(self):
        """Test loading risk classification model"""
        model_path = "machine_learning/profitability_models/risk_model.pkl"

        try:
            with open(model_path, "rb") as f:
                model = pickle.load(f)

            assert model is not None
            assert hasattr(model, "predict")
        except Exception as e:
            pytest.fail(f"Failed to load risk model: {e}")

    def test_load_scaler(self):
        """Test loading scaler"""
        scaler_path = "machine_learning/profitability_models/scaler.pkl"

        try:
            with open(scaler_path, "rb") as f:
                scaler = pickle.load(f)

            assert scaler is not None
            assert hasattr(scaler, "transform")
        except Exception as e:
            pytest.fail(f"Failed to load scaler: {e}")

    def test_load_label_encoders(self):
        """Test loading label encoders"""
        encoders_path = "machine_learning/profitability_models/label_encoders.pkl"

        try:
            with open(encoders_path, "rb") as f:
                encoders = pickle.load(f)

            assert isinstance(encoders, dict)
            assert len(encoders) > 0
        except Exception as e:
            pytest.fail(f"Failed to load encoders: {e}")


class TestCustomerModelFiles:
    """Test customer persona model files"""

    def test_customer_model_exists(self):
        """Test that customer classifier model exists"""
        model_path = "machine_learning/customer_models/customer_classifier.pkl"

        if os.path.exists(model_path):
            assert os.path.isfile(model_path)
        else:
            pytest.skip("Customer model not trained yet")

    def test_customer_encoders_exist(self):
        """Test that customer encoders exist"""
        encoders_path = "machine_learning/customer_models/customer_encoders.pkl"

        if os.path.exists(encoders_path):
            assert os.path.isfile(encoders_path)
        else:
            pytest.skip("Customer encoders not available")

    def test_customer_metadata_exists(self):
        """Test that customer model metadata exists"""
        metadata_path = "machine_learning/customer_models/customer_metadata.json"

        if os.path.exists(metadata_path):
            assert os.path.isfile(metadata_path)
        else:
            pytest.skip("Customer metadata not available")


@pytest.mark.skipif(
    not os.path.exists("machine_learning/customer_models/customer_classifier.pkl"),
    reason="Customer ML models not trained yet",
)
class TestCustomerModelLoading:
    """Test customer model loading"""

    def test_load_customer_classifier(self):
        """Test loading customer classifier model"""
        model_path = "machine_learning/customer_models/customer_classifier.pkl"

        try:
            with open(model_path, "rb") as f:
                model = pickle.load(f)

            assert model is not None
            assert hasattr(model, "predict")
        except Exception as e:
            pytest.fail(f"Failed to load customer model: {e}")

    def test_load_customer_encoders(self):
        """Test loading customer encoders"""
        encoders_path = "machine_learning/customer_models/customer_encoders.pkl"

        try:
            with open(encoders_path, "rb") as f:
                encoders = pickle.load(f)

            assert isinstance(encoders, dict)
        except Exception as e:
            pytest.fail(f"Failed to load customer encoders: {e}")


class TestDataFiles:
    """Test training data files"""

    def test_recipe_data_exists(self):
        """Test that recipe dataset exists"""
        data_path = "data/IndianFoodDatasetCSV.csv"

        if os.path.exists(data_path):
            assert os.path.isfile(data_path)
            assert os.path.getsize(data_path) > 1000000
        else:
            pytest.skip("Recipe data not available")

    def test_restaurant_training_data_exists(self):
        """Test that restaurant training data exists"""
        data_path = "data/restaurant_data_10k.csv"

        if os.path.exists(data_path):
            assert os.path.isfile(data_path)
        else:
            pytest.skip("Restaurant training data not generated")

    def test_customer_training_data_exists(self):
        """Test that customer training data exists"""
        data_path = "data/customer_training_data.csv"

        if os.path.exists(data_path):
            assert os.path.isfile(data_path)
        else:
            pytest.skip("Customer training data not generated")


class TestDatabase:
    """Test database functionality"""

    def test_database_creation(self, app):
        """Test that database can be created"""
        import sqlite3

        db_path = app.config["DATABASE"]
        assert os.path.exists(db_path)

        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]

        assert "users" in tables
        assert "waste_entries" in tables
        assert "waste_categories" in tables

        conn.close()

    def test_users_table_structure(self, app):
        """Test users table structure"""
        import sqlite3

        db_path = app.config["DATABASE"]
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("PRAGMA table_info(users)")
        columns = {row[1] for row in cursor.fetchall()}

        assert "id" in columns
        assert "name" in columns
        assert "email" in columns
        assert "password_hash" in columns

        conn.close()

    def test_waste_entries_table_structure(self, app):
        """Test waste_entries table structure"""
        import sqlite3

        db_path = app.config["DATABASE"]
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()

        cursor.execute("PRAGMA table_info(waste_entries)")
        columns = {row[1] for row in cursor.fetchall()}

        assert "id" in columns
        assert "item_name" in columns
        assert "category" in columns
        assert "quantity" in columns
        assert "cost_value" in columns

        conn.close()
