import pytest
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app import app as flask_app  # noqa: E402


@pytest.fixture
def app():
    """Create and configure a test Flask app instance"""
    db_fd, db_path = tempfile.mkstemp()

    flask_app.config.update(
        {
            "TESTING": True,
            "DATABASE": db_path,
            "SECRET_KEY": "test-secret-key",
            "WTF_CSRF_ENABLED": False,
        }
    )

    with flask_app.app_context():
        from app import init_database

        init_database()

    yield flask_app

    os.close(db_fd)
    os.unlink(db_path)


@pytest.fixture
def client(app):
    """Test client for making requests"""
    return app.test_client()


@pytest.fixture
def runner(app):
    """Test CLI runner"""
    return app.test_cli_runner()


@pytest.fixture
def auth_client(client):
    """Authenticated test client with logged-in user"""
    client.post(
        "/api/register",
        json={
            "full_name": "Test User",
            "email": "test@example.com",
            "business_name": "Test Restaurant",
            "password": "TestPassword123",
        },
    )

    client.post("/api/login", json={"email": "test@example.com", "password": "TestPassword123"})

    return client


@pytest.fixture
def sample_restaurant_data():
    """Sample restaurant data for testing predictions"""
    return {
        "city": "Mumbai",
        "location_type": "Mall",
        "cuisine_type": "North Indian",
        "seating_capacity": 50,
        "avg_table_size": 4,
        "parking_available": 1,
        "home_delivery": 1,
        "operating_hours": 12,
        "days_open_per_week": 7,
        "years_in_business": 2,
        "avg_daily_customers": 150,
        "customer_rating": 4.2,
        "online_orders_pct": 30,
        "avg_order_value": 450,
        "staff_count": 12,
        "chef_experience_years": 8,
        "food_quality_score": 8.0,
        "service_quality_score": 7.5,
        "ambiance_score": 8.0,
        "competitors_nearby": 5,
        "population_density": 8000,
        "foot_traffic": 2000,
        "rent_monthly": 120000,
        "staff_salary_monthly": 240000,
        "marketing_budget": 20000,
        "utility_cost": 15000,
        "food_cost_pct": 32,
    }


@pytest.fixture
def sample_customer_data():
    """Sample customer data for persona testing"""
    return {
        "time": 19,
        "budget_level": "high",
        "food_type": "dine_in",
        "occasion": "celebration",
        "customer_type": "family",
        "delivery_preference": "no_delivery",
        "payment_method": "card",
    }
