import pytest
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from features.personas import CustomerPersona  # noqa: E402


class TestPersonaIdentification:
    """Test customer persona identification logic"""

    def test_street_food_persona(self):
        """Test identification of street food persona"""
        criteria = {
            "time": 8,
            "budget_level": "low",
            "food_type": "street_food",
            "occasion": "daily_meal",
            "customer_type": "student",
            "delivery_preference": "self_pickup",
            "payment_method": "cash",
        }

        result = CustomerPersona.identify_persona(criteria)

        assert result["persona_key"] == "street_food"
        assert result["confidence"] > 0

    def test_fine_dining_persona(self):
        """Test identification of fine dining persona"""
        criteria = {
            "time": 20,
            "budget_level": "high",
            "food_type": "dine_in",
            "occasion": "celebration",
            "customer_type": "family",
            "delivery_preference": "no_delivery",
            "payment_method": "card",
        }

        result = CustomerPersona.identify_persona(criteria)

        assert result["persona_key"] == "fine_dining"
        assert result["confidence"] > 50

    def test_cloud_kitchen_persona(self):
        """Test identification of cloud kitchen persona"""
        criteria = {
            "time": 13,
            "budget_level": "medium",
            "food_type": "home_delivery",
            "occasion": "daily_meal",
            "customer_type": "working_professional",
            "delivery_preference": "app_delivery",
            "payment_method": "upi",
        }

        result = CustomerPersona.identify_persona(criteria)

        assert result["persona_key"] == "cloud_kitchen"

    def test_catering_persona(self):
        """Test identification of catering persona"""
        criteria = {
            "time": 15,
            "budget_level": "high",
            "food_type": "catering",
            "occasion": "event",
            "customer_type": "event_planner",
            "delivery_preference": "no_delivery",
            "payment_method": "online_transfer",
        }

        result = CustomerPersona.identify_persona(criteria)

        assert result["persona_key"] == "catering_events"

    def test_health_conscious_persona(self):
        """Test identification of health-conscious persona"""
        criteria = {
            "time": 8,
            "budget_level": "medium",
            "food_type": "health_conscious",
            "occasion": "daily_meal",
            "customer_type": "working_professional",
            "delivery_preference": "app_delivery",
            "payment_method": "card",
        }

        result = CustomerPersona.identify_persona(criteria)

        assert result["persona_key"] == "health_organic"

    def test_persona_output_structure(self):
        """Test that persona output has required fields"""
        criteria = {"time": 12, "budget_level": "medium", "food_type": "dine_in"}

        result = CustomerPersona.identify_persona(criteria)

        assert "persona_key" in result
        assert "persona_name" in result
        assert "confidence" in result
        assert "characteristics" in result
        assert "peak_times" in result
        assert "marketing_strategies" in result

    def test_minimal_criteria(self):
        """Test persona identification with minimal criteria"""
        criteria = {"budget_level": "low"}

        result = CustomerPersona.identify_persona(criteria)

        assert result is not None
        assert "persona_key" in result

    def test_empty_criteria(self):
        """Test persona identification with empty criteria"""
        criteria = {}

        result = CustomerPersona.identify_persona(criteria)

        assert result is not None
        assert result["confidence"] == 0 or result["persona_key"] == "general"


class TestPersonaData:
    """Test persona data structure and content"""

    def test_all_personas_exist(self):
        """Test that all expected personas are defined"""
        personas = CustomerPersona.PERSONAS

        expected_personas = [
            "street_food",
            "fast_casual",
            "fine_dining",
            "cloud_kitchen",
            "regional_specialty",
            "catering_events",
            "health_organic",
        ]

        for persona in expected_personas:
            assert persona in personas

    def test_persona_structure(self):
        """Test that each persona has required fields"""
        for persona_key, persona_data in CustomerPersona.PERSONAS.items():
            assert "name" in persona_data
            assert "characteristics" in persona_data
            assert "peak_times" in persona_data
            assert "avg_spending" in persona_data
            assert "marketing" in persona_data
            assert isinstance(persona_data["characteristics"], list)
            assert isinstance(persona_data["marketing"], list)

    def test_get_all_personas(self):
        """Test get_all_personas method"""
        all_personas = CustomerPersona.get_all_personas()

        assert isinstance(all_personas, dict)
        assert len(all_personas) == 7


class TestPeakTimeMatching:
    """Test peak time matching logic"""

    def test_morning_peak_time(self):
        """Test morning time matching"""
        criteria = {"time": 9}
        result = CustomerPersona.identify_persona(criteria)

        assert result is not None

    def test_lunch_peak_time(self):
        """Test lunch time matching"""
        criteria = {"time": 13}
        result = CustomerPersona.identify_persona(criteria)

        assert result is not None

    def test_dinner_peak_time(self):
        """Test dinner time matching"""
        criteria = {"time": 20}
        result = CustomerPersona.identify_persona(criteria)

        assert result is not None

    def test_late_night_time(self):
        """Test late night time matching"""
        criteria = {"time": 23}
        result = CustomerPersona.identify_persona(criteria)

        assert result is not None


@pytest.mark.skipif(
    not os.path.exists("machine_learning/customer_models/customer_classifier.pkl"),
    reason="Customer ML models not trained yet",
)
class TestMLPersonaPrediction:
    """Test ML-based persona prediction"""

    def test_ml_predictor_initialization(self):
        """Test ML predictor can be initialized"""
        from machine_learning.customer_predictor import CustomerPersonaPredictor

        try:
            predictor = CustomerPersonaPredictor()
            assert predictor is not None
        except Exception as e:
            pytest.skip(f"ML models not available: {e}")

    def test_ml_prediction_output_format(self, sample_customer_data):
        """Test ML prediction output format"""
        from machine_learning.customer_predictor import CustomerPersonaPredictor

        try:
            predictor = CustomerPersonaPredictor()
            result = predictor.predict(sample_customer_data)

            assert isinstance(result, dict)
            assert "persona" in result
            assert "confidence" in result
        except Exception as e:
            pytest.skip(f"ML prediction failed: {e}")

    def test_ml_prediction_consistency(self, sample_customer_data):
        """Test ML prediction consistency"""
        from machine_learning.customer_predictor import CustomerPersonaPredictor

        try:
            predictor = CustomerPersonaPredictor()
            result1 = predictor.predict(sample_customer_data)
            result2 = predictor.predict(sample_customer_data)

            assert result1["persona"] == result2["persona"]
        except Exception as e:
            pytest.skip(f"ML prediction failed: {e}")


class TestPersonaRecommendations:
    """Test persona-based recommendations"""

    def test_marketing_strategies_exist(self):
        """Test that marketing strategies exist for all personas"""
        for persona_key, persona_data in CustomerPersona.PERSONAS.items():
            assert len(persona_data["marketing"]) > 0

    def test_characteristics_defined(self):
        """Test that characteristics are defined for all personas"""
        for persona_key, persona_data in CustomerPersona.PERSONAS.items():
            assert len(persona_data["characteristics"]) > 0

    def test_spending_range_defined(self):
        """Test that spending ranges are defined"""
        for persona_key, persona_data in CustomerPersona.PERSONAS.items():
            assert "₹" in persona_data["avg_spending"]
