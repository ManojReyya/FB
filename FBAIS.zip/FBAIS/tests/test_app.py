import json
from app import hash_password, verify_password


class TestAuthentication:
    """Test user authentication functionality"""

    def test_register_success(self, client):
        """Test successful user registration"""
        response = client.post(
            "/api/register",
            json={
                "full_name": "John Doe",
                "email": "john@example.com",
                "business_name": "John Restaurant",
                "password": "SecurePass123",
            },
        )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True
        assert "Account created" in data["message"]

    def test_register_duplicate_email(self, client):
        """Test registration with duplicate email fails"""
        client.post(
            "/api/register",
            json={
                "full_name": "User One",
                "email": "duplicate@example.com",
                "password": "Password123",
            },
        )

        response = client.post(
            "/api/register",
            json={
                "full_name": "User Two",
                "email": "duplicate@example.com",
                "password": "Password456",
            },
        )

        assert response.status_code == 409
        data = json.loads(response.data)
        assert data["success"] is False
        assert "already registered" in data["error"]

    def test_register_missing_fields(self, client):
        """Test registration with missing fields fails"""
        response = client.post("/api/register", json={"email": "incomplete@example.com"})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["success"] is False

    def test_register_weak_password(self, client):
        """Test registration with weak password fails"""
        response = client.post(
            "/api/register",
            json={"full_name": "Test User", "email": "test@example.com", "password": "weak"},
        )

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["success"] is False
        assert "8+" in data["error"]

    def test_login_success(self, client):
        """Test successful login"""
        client.post(
            "/api/register",
            json={
                "full_name": "Test User",
                "email": "login@example.com",
                "password": "TestPass123",
            },
        )

        response = client.post(
            "/api/login", json={"email": "login@example.com", "password": "TestPass123"}
        )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True

    def test_login_invalid_credentials(self, client):
        """Test login with invalid credentials fails"""
        response = client.post(
            "/api/login", json={"email": "notexist@example.com", "password": "wrongpass"}
        )

        assert response.status_code == 401
        data = json.loads(response.data)
        assert data["success"] is False
        assert "Invalid" in data["error"]

    def test_login_missing_fields(self, client):
        """Test login with missing fields fails"""
        response = client.post("/api/login", json={"email": "test@example.com"})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["success"] is False

    def test_logout(self, auth_client):
        """Test logout functionality"""
        response = auth_client.get("/api/logout")
        assert response.status_code == 302

    def test_password_hashing(self):
        """Test password hashing and verification"""
        password = "mysecretpassword"
        hashed = hash_password(password)

        assert hashed != password
        assert verify_password(password, hashed) is True
        assert verify_password("wrongpassword", hashed) is False


class TestRoutes:
    """Test application routes"""

    def test_index_unauthenticated(self, client):
        """Test index route redirects to landing when not logged in"""
        response = client.get("/")
        assert response.status_code == 200
        assert b"landing" in response.data or b"Landing" in response.data

    def test_index_authenticated(self, auth_client):
        """Test index route shows dashboard when logged in"""
        response = auth_client.get("/")
        assert response.status_code == 200
        assert b"dashboard" in response.data or b"Dashboard" in response.data

    def test_landing_page(self, client):
        """Test landing page accessible"""
        response = client.get("/landing")
        assert response.status_code == 200

    def test_dashboard_requires_login(self, client):
        """Test dashboard requires authentication"""
        response = client.get("/dashboard")
        assert response.status_code == 302

    def test_dashboard_authenticated(self, auth_client):
        """Test dashboard accessible when logged in"""
        response = auth_client.get("/dashboard")
        assert response.status_code == 200

    def test_profitability_requires_login(self, client):
        """Test profitability page requires authentication"""
        response = client.get("/profitability-prediction")
        assert response.status_code == 302

    def test_profitability_authenticated(self, auth_client):
        """Test profitability page accessible when logged in"""
        response = auth_client.get("/profitability-prediction")
        assert response.status_code == 200

    def test_inventory_requires_login(self, client):
        """Test inventory page requires authentication"""
        response = client.get("/inventory-recipes")
        assert response.status_code == 302

    def test_inventory_authenticated(self, auth_client):
        """Test inventory page accessible when logged in"""
        response = auth_client.get("/inventory-recipes")
        assert response.status_code == 200

    def test_customer_personas_requires_login(self, client):
        """Test customer personas page requires authentication"""
        response = client.get("/customer-personas")
        assert response.status_code == 302

    def test_customer_personas_authenticated(self, auth_client):
        """Test customer personas page accessible when logged in"""
        response = auth_client.get("/customer-personas")
        assert response.status_code == 200

    def test_profile_requires_login(self, client):
        """Test profile page requires authentication"""
        response = client.get("/profile")
        assert response.status_code == 302

    def test_profile_authenticated(self, auth_client):
        """Test profile page accessible when logged in"""
        response = auth_client.get("/profile")
        assert response.status_code == 200

    def test_health_check(self, client):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["status"] == "healthy"
        assert data["app"] == "FBAIS"


class TestProfileUpdate:
    """Test profile update functionality"""

    def test_update_profile_success(self, auth_client):
        """Test successful profile update"""
        response = auth_client.post(
            "/api/update-profile",
            json={
                "name": "Updated Name",
                "business_name": "Updated Business",
                "phone": "1234567890",
            },
        )

        assert response.status_code == 200
        data = json.loads(response.data)
        assert data["success"] is True

    def test_update_profile_missing_name(self, auth_client):
        """Test profile update with missing name fails"""
        response = auth_client.post("/api/update-profile", json={"business_name": "Business"})

        assert response.status_code == 400
        data = json.loads(response.data)
        assert data["success"] is False

    def test_update_profile_requires_login(self, client):
        """Test profile update requires authentication"""
        response = client.post("/api/update-profile", json={"name": "Test"})

        assert response.status_code == 302
