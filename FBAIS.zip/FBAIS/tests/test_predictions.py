import pytest
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


@pytest.mark.skipif(
    not os.path.exists("machine_learning/profitability_models/profit_model.pkl"),
    reason="ML models not trained yet",
)
class TestProfitPrediction:
    """Test profit prediction model functionality"""

    def test_predictor_initialization(self):
        """Test that predictor can be initialized"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            assert predictor is not None
        except Exception as e:
            pytest.skip(f"Models not available: {e}")

    def test_profit_prediction_output_format(self, sample_restaurant_data):
        """Test that prediction returns expected format"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            result = predictor.predict_all(sample_restaurant_data)

            assert isinstance(result, dict)
            assert "predicted_profit" in result
            assert "risk_level" in result
            assert isinstance(result["predicted_profit"], (int, float))
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")

    def test_profit_prediction_reasonable_range(self, sample_restaurant_data):
        """Test that predicted profit is in reasonable range"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            result = predictor.predict_all(sample_restaurant_data)

            profit = result["predicted_profit"]
            assert -1000000 <= profit <= 10000000
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")

    def test_risk_classification_valid(self, sample_restaurant_data):
        """Test that risk classification returns valid level"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            result = predictor.predict_all(sample_restaurant_data)

            assert result["risk_level"] in ["Low", "Medium", "High"]
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")

    def test_multiple_predictions_consistency(self, sample_restaurant_data):
        """Test that same input produces consistent predictions"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            result1 = predictor.predict_all(sample_restaurant_data)
            result2 = predictor.predict_all(sample_restaurant_data)

            assert result1["predicted_profit"] == result2["predicted_profit"]
            assert result1["risk_level"] == result2["risk_level"]
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")

    def test_high_customers_higher_profit(self):
        """Test that more customers generally leads to higher profit"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()

            data_low = {
                "city": "Mumbai",
                "location_type": "Street",
                "cuisine_type": "North Indian",
                "seating_capacity": 30,
                "avg_table_size": 4,
                "parking_available": 0,
                "home_delivery": 1,
                "operating_hours": 10,
                "days_open_per_week": 7,
                "years_in_business": 1,
                "avg_daily_customers": 50,
                "customer_rating": 3.5,
                "online_orders_pct": 20,
                "avg_order_value": 300,
                "staff_count": 5,
                "chef_experience_years": 3,
                "food_quality_score": 6.0,
                "service_quality_score": 6.0,
                "ambiance_score": 5.0,
                "competitors_nearby": 10,
                "population_density": 5000,
                "foot_traffic": 1000,
                "rent_monthly": 50000,
                "staff_salary_monthly": 100000,
                "marketing_budget": 10000,
                "utility_cost": 8000,
                "food_cost_pct": 40,
            }

            data_high = data_low.copy()
            data_high["avg_daily_customers"] = 200

            profit_low = predictor.predict_all(data_low)["predicted_profit"]
            profit_high = predictor.predict_all(data_high)["predicted_profit"]

            assert profit_high > profit_low
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")


class TestPredictionValidation:
    """Test input validation for predictions"""

    def test_missing_required_fields(self):
        """Test that missing fields are handled"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()

            with pytest.raises(Exception):
                predictor.predict_all({"city": "Mumbai"})
        except Exception as e:
            pytest.skip(f"Models not available: {e}")

    def test_invalid_data_types(self):
        """Test that invalid data types are handled"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()

            invalid_data = {
                "city": "Mumbai",
                "location_type": "Mall",
                "cuisine_type": "North Indian",
                "seating_capacity": "invalid",
                "avg_table_size": 4,
                "parking_available": 0,
                "home_delivery": 1,
                "operating_hours": 10,
                "days_open_per_week": 7,
                "years_in_business": 1,
                "avg_daily_customers": 100,
                "customer_rating": 4.0,
                "online_orders_pct": 20,
                "avg_order_value": 400,
                "staff_count": 10,
                "chef_experience_years": 5,
                "food_quality_score": 7.5,
                "service_quality_score": 7.5,
                "ambiance_score": 7.0,
                "competitors_nearby": 5,
                "population_density": 5000,
                "foot_traffic": 1500,
                "rent_monthly": 100000,
                "staff_salary_monthly": 200000,
                "marketing_budget": 15000,
                "utility_cost": 10000,
                "food_cost_pct": 35,
            }

            with pytest.raises(Exception):
                predictor.predict_all(invalid_data)
        except Exception as e:
            pytest.skip(f"Models not available: {e}")


class TestRecommendations:
    """Test recommendation generation"""

    def test_recommendations_exist(self, sample_restaurant_data):
        """Test that recommendations are generated"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            result = predictor.predict_all(sample_restaurant_data)

            assert "recommendations" in result
            assert isinstance(result["recommendations"], list)
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")

    def test_recommendations_not_empty(self, sample_restaurant_data):
        """Test that at least some recommendations are provided"""
        from machine_learning.restaurant_prediction_pipeline import RestaurantProfitabilityPredictor

        try:
            predictor = RestaurantProfitabilityPredictor()
            result = predictor.predict_all(sample_restaurant_data)

            assert len(result["recommendations"]) > 0
        except Exception as e:
            pytest.skip(f"Model prediction failed: {e}")
