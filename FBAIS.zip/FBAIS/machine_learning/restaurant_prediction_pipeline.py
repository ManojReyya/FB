"""
Restaurant Profitability Prediction Pipeline
Makes predictions using pre-trained ML models
"""

import pickle
import pandas as pd


class RestaurantProfitabilityPredictor:
    """Predict restaurant profit and risk using trained models"""

    def __init__(self, model_dir="machine_learning/profitability_models"):
        self.model_dir = model_dir
        self._load_models()

    def _load_models(self):
        """Load trained models and preprocessors"""
        try:
            print("Loading ML models...")

            model_files = [
                "profit_model",
                "risk_model",
                "scaler",
                "label_encoders",
                "feature_columns",
            ]
            loaded = {}

            for name in model_files:
                with open(f"{self.model_dir}/{name}.pkl", "rb") as f:
                    loaded[name] = pickle.load(f)

            self.profit_model = loaded["profit_model"]
            self.risk_model = loaded["risk_model"]
            self.scaler = loaded["scaler"]
            self.label_encoders = loaded["label_encoders"]
            self.feature_info = loaded["feature_columns"]

            print("✓ Models loaded successfully")

        except FileNotFoundError as e:
            print(f"✗ Model files not found: {e}")
            raise

    def prepare_input(self, input_data):
        """Transform input data for model prediction"""
        df = pd.DataFrame([input_data])

        # Encode categorical features
        for col in self.feature_info["categorical_columns"]:
            if col in df.columns:
                try:
                    encoded = self.label_encoders[col].transform([df[col].iloc[0]])[0]
                except ValueError:
                    encoded = 0  # Default for unseen categories
                df[f"{col}_encoded"] = encoded

        # Select and scale features
        X = df[self.feature_info["feature_columns"]]
        return self.scaler.transform(X)

    def predict_profit(self, input_data):
        """Predict monthly profit"""
        X = self.prepare_input(input_data)
        predicted_profit = self.profit_model.predict(X)[0]

        # Calculate financials
        monthly_revenue = (
            input_data["avg_daily_customers"]
            * input_data["avg_order_value"]
            * input_data["days_open_per_week"]
            * 4.33
        )
        monthly_costs = monthly_revenue - predicted_profit
        profit_margin = (predicted_profit / monthly_revenue * 100) if monthly_revenue > 0 else 0

        return {
            "monthly_profit": round(predicted_profit, 2),
            "monthly_revenue": round(monthly_revenue, 2),
            "monthly_costs": round(monthly_costs, 2),
            "profit_margin": round(profit_margin, 2),
        }

    def predict_risk(self, input_data):
        """Predict business risk level"""
        X = self.prepare_input(input_data)

        risk_encoded = self.risk_model.predict(X)[0]
        risk_probs = self.risk_model.predict_proba(X)[0]

        risk_level = self.label_encoders["risk_level"].inverse_transform([risk_encoded])[0]
        risk_classes = self.label_encoders["risk_level"].classes_

        return {
            "risk_level": risk_level,
            "risk_probabilities": {
                risk_classes[i]: round(float(risk_probs[i]) * 100, 2)
                for i in range(len(risk_classes))
            },
            "confidence": round(float(max(risk_probs)) * 100, 2),
        }

    def predict_all(self, input_data):
        """Complete prediction with recommendations"""
        profit_result = self.predict_profit(input_data)
        risk_result = self.predict_risk(input_data)

        return {
            "profit_prediction": profit_result,
            "risk_assessment": risk_result,
            "recommendations": self._get_recommendations(input_data, profit_result, risk_result),
            "input_summary": {
                "location": f"{input_data.get('city', 'Unknown')}, {input_data.get('location_type', 'Unknown')}",
                "cuisine": input_data.get("cuisine_type", "Unknown"),
                "capacity": input_data.get("seating_capacity", 0),
                "daily_customers": input_data.get("avg_daily_customers", 0),
                "avg_order_value": input_data.get("avg_order_value", 0),
                "rating": input_data.get("customer_rating", 0),
            },
        }

    def _get_recommendations(self, data, profit, risk):
        """Generate actionable business recommendations"""
        recs = []

        # Profit analysis
        margin = profit["profit_margin"]
        if margin < 5:
            recs.append(
                {
                    "type": "warning",
                    "category": "Profitability",
                    "message": "Low profit margin. Reduce costs or increase prices.",
                    "priority": "high",
                }
            )
        elif margin > 20:
            recs.append(
                {
                    "type": "success",
                    "category": "Growth",
                    "message": "Excellent margins! Consider expansion.",
                    "priority": "low",
                }
            )

        # Customer satisfaction
        if data.get("customer_rating", 0) < 3.5:
            recs.append(
                {
                    "type": "warning",
                    "category": "Customer Satisfaction",
                    "message": "Low ratings. Improve food quality and service.",
                    "priority": "high",
                }
            )

        # Market competition
        if data.get("competitors_nearby", 0) > 15:
            recs.append(
                {
                    "type": "info",
                    "category": "Competition",
                    "message": "High competition. Focus on unique value proposition.",
                    "priority": "medium",
                }
            )

        # Cost optimization
        if data.get("food_cost_pct", 0) > 40:
            recs.append(
                {
                    "type": "warning",
                    "category": "Cost Control",
                    "message": "High food costs. Negotiate with suppliers.",
                    "priority": "high",
                }
            )

        # Digital presence
        if data.get("online_orders_pct", 0) < 20:
            recs.append(
                {
                    "type": "info",
                    "category": "Digital",
                    "message": "Low online orders. Boost digital presence.",
                    "priority": "medium",
                }
            )

        # Risk warning
        if risk["risk_level"] == "High":
            recs.append(
                {
                    "type": "danger",
                    "category": "Risk",
                    "message": "High business risk. Review financial model.",
                    "priority": "critical",
                }
            )

        return recs

    def get_feature_importance(self, top_n=10):
        """Get most important features for predictions"""
        importances = self.profit_model.feature_importances_
        features = self.feature_info["feature_columns"]

        ranked = sorted(zip(features, importances), key=lambda x: x[1], reverse=True)

        return [
            {"feature": name, "importance": round(float(imp), 4)} for name, imp in ranked[:top_n]
        ]


if __name__ == "__main__":
    # Quick test
    predictor = RestaurantProfitabilityPredictor()

    test_data = {
        "city": "Mumbai",
        "location_type": "Mall",
        "cuisine_type": "Multi-Cuisine",
        "seating_capacity": 80,
        "avg_table_size": 4,
        "parking_available": 1,
        "home_delivery": 1,
        "operating_hours": 12,
        "days_open_per_week": 7,
        "years_in_business": 3,
        "avg_daily_customers": 200,
        "customer_rating": 4.2,
        "online_orders_pct": 35,
        "avg_order_value": 600,
        "staff_count": 15,
        "chef_experience_years": 8,
        "food_quality_score": 8.5,
        "service_quality_score": 8.0,
        "ambiance_score": 8.0,
        "competitors_nearby": 8,
        "population_density": 12000,
        "foot_traffic": 3500,
        "rent_monthly": 150000,
        "staff_salary_monthly": 300000,
        "marketing_budget": 25000,
        "utility_cost": 15000,
        "food_cost_pct": 32,
    }

    result = predictor.predict_all(test_data)

    print("\n" + "=" * 60)
    print("PREDICTION TEST")
    print("=" * 60)
    print(f"\nProfit: ₹{result['profit_prediction']['monthly_profit']:,.0f}")
    print(f"Margin: {result['profit_prediction']['profit_margin']:.1f}%")
    print(
        f"Risk: {result['risk_assessment']['risk_level']} ({result['risk_assessment']['confidence']:.0f}% confident)"
    )
    print(f"\nRecommendations: {len(result['recommendations'])}")
    for rec in result["recommendations"]:
        print(f"  • {rec['message']}")
