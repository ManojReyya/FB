"""
Restaurant Profitability Model Trainer
Trains machine learning models for profit prediction and risk classification
"""

import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from datetime import datetime

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.metrics import (
    mean_squared_error,
    r2_score,
    mean_absolute_error,
    accuracy_score,
    classification_report,
    confusion_matrix,
)


class RestaurantProfitabilityModelTrainer:
    """Train and evaluate restaurant profitability prediction models"""

    def __init__(self, data_path="data/restaurant_data_10k.csv"):
        """
        Initialize trainer

        Args:
            data_path: Path to training data CSV
        """
        self.data_path = data_path
        self.df = None

        # Models
        self.profit_model = None
        self.risk_model = None

        # Encoders and scalers
        self.label_encoders = {}
        self.scaler = StandardScaler()

        # Feature columns
        self.feature_columns = []
        self.categorical_columns = []
        self.numerical_columns = []

        # Model performance
        self.metrics = {}

    def load_data(self):
        """Load and prepare training data"""
        print("Loading training data...")
        self.df = pd.read_csv(self.data_path)
        print(f"✓ Loaded {len(self.df)} records")
        print(f"  Columns: {len(self.df.columns)}")

        # Identify feature columns
        self._identify_features()

        return self.df

    def _identify_features(self):
        """Identify categorical and numerical features"""
        # Categorical columns to encode
        self.categorical_columns = ["city", "location_type", "cuisine_type"]

        # Numerical features for prediction
        self.numerical_columns = [
            "seating_capacity",
            "avg_table_size",
            "parking_available",
            "home_delivery",
            "operating_hours",
            "days_open_per_week",
            "years_in_business",
            "avg_daily_customers",
            "customer_rating",
            "online_orders_pct",
            "avg_order_value",
            "staff_count",
            "chef_experience_years",
            "food_quality_score",
            "service_quality_score",
            "ambiance_score",
            "competitors_nearby",
            "population_density",
            "foot_traffic",
            "rent_monthly",
            "staff_salary_monthly",
            "marketing_budget",
            "utility_cost",
            "food_cost_pct",
        ]

        print(f"✓ Feature identification complete")
        print(f"  Categorical features: {len(self.categorical_columns)}")
        print(f"  Numerical features: {len(self.numerical_columns)}")

    def prepare_features(self):
        """Encode categorical features and prepare feature matrix"""
        print("\nPreparing features...")

        df_processed = self.df.copy()

        # Encode categorical variables
        for col in self.categorical_columns:
            le = LabelEncoder()
            df_processed[f"{col}_encoded"] = le.fit_transform(df_processed[col])
            self.label_encoders[col] = le
            print(f"  Encoded {col}: {len(le.classes_)} unique values")

        # Prepare feature columns list
        self.feature_columns = self.numerical_columns + [
            f"{col}_encoded" for col in self.categorical_columns
        ]

        print(f"✓ Feature preparation complete: {len(self.feature_columns)} total features")

        return df_processed

    def train_profit_model(self, df_processed, test_size=0.2):
        """
        Train profit prediction model

        Args:
            df_processed: Preprocessed dataframe
            test_size: Test set proportion
        """
        print("\n" + "=" * 60)
        print("TRAINING PROFIT PREDICTION MODEL")
        print("=" * 60)

        # Prepare data
        X = df_processed[self.feature_columns]
        y = df_processed["monthly_profit"]

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )

        print(f"Training set: {len(X_train)} samples")
        print(f"Test set: {len(X_test)} samples")

        # Scale features
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # Train Random Forest Regressor
        print("\nTraining Random Forest Regressor...")
        self.profit_model = RandomForestRegressor(
            n_estimators=100,
            max_depth=20,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1,
        )

        self.profit_model.fit(X_train_scaled, y_train)

        # Predictions
        y_pred_train = self.profit_model.predict(X_train_scaled)
        y_pred_test = self.profit_model.predict(X_test_scaled)

        # Evaluate
        train_r2 = r2_score(y_train, y_pred_train)
        test_r2 = r2_score(y_test, y_pred_test)
        test_rmse = np.sqrt(mean_squared_error(y_test, y_pred_test))
        test_mae = mean_absolute_error(y_test, y_pred_test)

        self.metrics["profit_model"] = {
            "train_r2": train_r2,
            "test_r2": test_r2,
            "test_rmse": test_rmse,
            "test_mae": test_mae,
        }

        print("\n✓ Model Training Complete!")
        print(f"  Train R² Score: {train_r2:.4f}")
        print(f"  Test R² Score: {test_r2:.4f}")
        print(f"  Test RMSE: ₹{test_rmse:,.2f}")
        print(f"  Test MAE: ₹{test_mae:,.2f}")

        # Feature importance
        feature_importance = pd.DataFrame(
            {"feature": self.feature_columns, "importance": self.profit_model.feature_importances_}
        ).sort_values("importance", ascending=False)

        print("\nTop 10 Most Important Features:")
        for idx, row in feature_importance.head(10).iterrows():
            print(f"  {row['feature']}: {row['importance']:.4f}")

        return self.profit_model

    def train_risk_model(self, df_processed, test_size=0.2):
        """
        Train risk classification model

        Args:
            df_processed: Preprocessed dataframe
            test_size: Test set proportion
        """
        print("\n" + "=" * 60)
        print("TRAINING RISK CLASSIFICATION MODEL")
        print("=" * 60)

        # Prepare data
        X = df_processed[self.feature_columns]
        y = df_processed["risk_level"]

        # Encode target
        le_risk = LabelEncoder()
        y_encoded = le_risk.fit_transform(y)
        self.label_encoders["risk_level"] = le_risk

        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y_encoded, test_size=test_size, random_state=42, stratify=y_encoded
        )

        print(f"Training set: {len(X_train)} samples")
        print(f"Test set: {len(X_test)} samples")

        # Use already fitted scaler
        X_train_scaled = self.scaler.transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)

        # Train Random Forest Classifier
        print("\nTraining Random Forest Classifier...")
        self.risk_model = RandomForestClassifier(
            n_estimators=100,
            max_depth=15,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1,
            class_weight="balanced",
        )

        self.risk_model.fit(X_train_scaled, y_train)

        # Predictions
        y_pred_train = self.risk_model.predict(X_train_scaled)
        y_pred_test = self.risk_model.predict(X_test_scaled)

        # Evaluate
        train_acc = accuracy_score(y_train, y_pred_train)
        test_acc = accuracy_score(y_test, y_pred_test)

        self.metrics["risk_model"] = {"train_accuracy": train_acc, "test_accuracy": test_acc}

        print("\n✓ Model Training Complete!")
        print(f"  Train Accuracy: {train_acc:.4f}")
        print(f"  Test Accuracy: {test_acc:.4f}")

        # Classification report
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred_test, target_names=le_risk.classes_))

        # Confusion matrix
        print("Confusion Matrix:")
        cm = confusion_matrix(y_test, y_pred_test)
        print(cm)

        return self.risk_model

    def save_models(self, output_dir="machine_learning/profitability_models"):
        """
        Save trained models and encoders

        Args:
            output_dir: Directory to save model files
        """
        print("\n" + "=" * 60)
        print("SAVING MODELS")
        print("=" * 60)

        # Create output directory
        Path(output_dir).mkdir(parents=True, exist_ok=True)

        # Save profit model
        profit_path = f"{output_dir}/profit_model.pkl"
        with open(profit_path, "wb") as f:
            pickle.dump(self.profit_model, f)
        print(f"✓ Saved profit model: {profit_path}")

        # Save risk model
        risk_path = f"{output_dir}/risk_model.pkl"
        with open(risk_path, "wb") as f:
            pickle.dump(self.risk_model, f)
        print(f"✓ Saved risk model: {risk_path}")

        # Save scaler
        scaler_path = f"{output_dir}/scaler.pkl"
        with open(scaler_path, "wb") as f:
            pickle.dump(self.scaler, f)
        print(f"✓ Saved scaler: {scaler_path}")

        # Save label encoders
        encoders_path = f"{output_dir}/label_encoders.pkl"
        with open(encoders_path, "wb") as f:
            pickle.dump(self.label_encoders, f)
        print(f"✓ Saved label encoders: {encoders_path}")

        # Save feature columns
        features_path = f"{output_dir}/feature_columns.pkl"
        with open(features_path, "wb") as f:
            pickle.dump(
                {
                    "feature_columns": self.feature_columns,
                    "categorical_columns": self.categorical_columns,
                    "numerical_columns": self.numerical_columns,
                },
                f,
            )
        print(f"✓ Saved feature columns: {features_path}")

        # Save metrics
        metrics_path = f"{output_dir}/metrics.pkl"
        with open(metrics_path, "wb") as f:
            pickle.dump(self.metrics, f)
        print(f"✓ Saved metrics: {metrics_path}")

        print(f"\n✓ All models saved to {output_dir}/")

    def train_all(self):
        """Complete training pipeline"""
        print("\n" + "=" * 70)
        print("RESTAURANT PROFITABILITY MODEL TRAINING PIPELINE")
        print("=" * 70)
        print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 70)

        # Load data
        self.load_data()

        # Prepare features
        df_processed = self.prepare_features()

        # Train models
        self.train_profit_model(df_processed)
        self.train_risk_model(df_processed)

        # Save models
        self.save_models()

        print("\n" + "=" * 70)
        print("TRAINING COMPLETE!")
        print("=" * 70)
        print(f"Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("\nModel Performance Summary:")
        print(f"  Profit Model R² Score: {self.metrics['profit_model']['test_r2']:.4f}")
        print(f"  Risk Model Accuracy: {self.metrics['risk_model']['test_accuracy']:.4f}")
        print("=" * 70)


def train_models(data_path="data/restaurant_data_10k.csv"):
    """
    Train all models

    Args:
        data_path: Path to training data
    """
    trainer = RestaurantProfitabilityModelTrainer(data_path)
    trainer.train_all()
    return trainer


if __name__ == "__main__":
    # Train models
    trainer = train_models()
