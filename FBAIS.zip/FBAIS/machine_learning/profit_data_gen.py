"""
Restaurant Data Generator for India State Capitals
Generates synthetic restaurant business data with realistic patterns
for 36 Indian state and union territory capitals
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random


class RestaurantDataGenerator:
    """Generate realistic restaurant business data for Indian state capitals"""

    # Indian state and union territory capitals
    INDIA_CAPITALS = [
        # States
        "Mumbai",
        "Bengaluru",
        "Chennai",
        "Kolkata",
        "Hyderabad",
        "Ahmedabad",
        "Pune",
        "Jaipur",
        "Lucknow",
        "Kanpur",
        "Nagpur",
        "Indore",
        "Bhopal",
        "Patna",
        "Vadodara",
        "Ludhiana",
        "Agra",
        "Nashik",
        "Faridabad",
        "Meerut",
        "Rajkot",
        "Varanasi",
        "Srinagar",
        "Aurangabad",
        "Dhanbad",
        "Amritsar",
        "Allahabad",
        "Ranchi",
        "Guwahati",
        "Chandigarh",
        # Union Territory Capitals
        "New Delhi",
        "Puducherry",
        "Port Blair",
        "Silvassa",
        "Daman",
        "Kavaratti",
    ]

    CUISINES = [
        "North Indian",
        "South Indian",
        "Chinese",
        "Continental",
        "Fast Food",
        "Multi-Cuisine",
        "Cafe",
        "Bakery",
        "Street Food",
        "Regional",
        "Fusion",
        "Vegetarian",
    ]

    LOCATION_TYPES = [
        "Mall",
        "Street",
        "Market",
        "IT Park",
        "Residential",
        "Commercial",
        "Highway",
        "Airport",
        "Railway Station",
        "Tourist Spot",
    ]

    def __init__(self, n_samples=10000, random_seed=42):
        """
        Initialize data generator

        Args:
            n_samples: Number of restaurant records to generate
            random_seed: Random seed for reproducibility
        """
        self.n_samples = n_samples
        np.random.seed(random_seed)
        random.seed(random_seed)

    def generate_data(self):
        """
        Generate complete restaurant dataset

        Returns:
            pandas.DataFrame: Restaurant business data
        """
        print(f"Generating {self.n_samples} restaurant records for India state capitals...")

        data = []

        for i in range(self.n_samples):
            # Basic information
            city = np.random.choice(self.INDIA_CAPITALS)
            cuisine_type = np.random.choice(self.CUISINES)
            location_type = np.random.choice(self.LOCATION_TYPES)

            # Size and capacity
            seating_capacity = np.random.randint(20, 200)
            avg_table_size = np.random.uniform(2, 6)

            # Operating parameters
            operating_hours = np.random.uniform(8, 18)
            days_open_per_week = np.random.randint(5, 8)

            # Customer metrics
            avg_daily_customers = np.random.randint(50, 500)
            customer_rating = np.random.uniform(2.5, 5.0)
            online_orders_pct = np.random.uniform(0, 60)

            # Financial metrics
            avg_order_value = np.random.uniform(150, 1500)  # INR
            rent_monthly = self._calculate_rent(city, seating_capacity, location_type)
            staff_count = int(seating_capacity / 10) + np.random.randint(2, 8)
            staff_salary_monthly = staff_count * np.random.uniform(12000, 30000)

            # Cost structure
            food_cost_pct = np.random.uniform(25, 45)
            marketing_budget = np.random.uniform(5000, 50000)
            utility_cost = np.random.uniform(5000, 25000)

            # Experience and quality factors
            years_in_business = np.random.uniform(0.5, 20)
            chef_experience_years = np.random.uniform(1, 25)
            food_quality_score = np.random.uniform(6, 10)
            service_quality_score = np.random.uniform(5, 10)
            ambiance_score = np.random.uniform(4, 10)

            # Competition and market
            competitors_nearby = np.random.randint(0, 25)
            population_density = self._get_population_density(city)
            foot_traffic = self._calculate_foot_traffic(location_type, population_density)

            # Additional factors
            parking_available = np.random.choice([0, 1], p=[0.3, 0.7])
            home_delivery = np.random.choice([0, 1], p=[0.2, 0.8])
            seasonal_variation = np.random.uniform(-20, 30)

            # Calculate revenue and costs
            monthly_revenue = (
                avg_daily_customers
                * avg_order_value
                * days_open_per_week
                * 4.33
                * (1 + seasonal_variation / 100)
            )

            monthly_food_cost = monthly_revenue * (food_cost_pct / 100)
            monthly_total_cost = (
                monthly_food_cost
                + rent_monthly
                + staff_salary_monthly
                + marketing_budget
                + utility_cost
            )

            # Calculate profit
            monthly_profit = monthly_revenue - monthly_total_cost
            profit_margin = (monthly_profit / monthly_revenue * 100) if monthly_revenue > 0 else 0

            # Risk classification
            if profit_margin > 15:
                risk_level = "Low"
            elif profit_margin > 5:
                risk_level = "Medium"
            else:
                risk_level = "High"

            # Success score (0-100)
            success_score = min(
                100,
                max(
                    0,
                    (profit_margin * 2)
                    + (customer_rating * 10)
                    + (food_quality_score * 3)
                    + (service_quality_score * 2)
                    + (years_in_business * 1.5)
                    - (competitors_nearby * 0.5),
                ),
            )

            # Create record
            record = {
                # Location
                "city": city,
                "location_type": location_type,
                "population_density": population_density,
                "foot_traffic": foot_traffic,
                # Restaurant details
                "cuisine_type": cuisine_type,
                "seating_capacity": seating_capacity,
                "avg_table_size": avg_table_size,
                "parking_available": parking_available,
                "home_delivery": home_delivery,
                # Operating metrics
                "operating_hours": operating_hours,
                "days_open_per_week": days_open_per_week,
                "years_in_business": years_in_business,
                # Customer metrics
                "avg_daily_customers": avg_daily_customers,
                "customer_rating": customer_rating,
                "online_orders_pct": online_orders_pct,
                "avg_order_value": avg_order_value,
                # Staff
                "staff_count": staff_count,
                "chef_experience_years": chef_experience_years,
                # Quality scores
                "food_quality_score": food_quality_score,
                "service_quality_score": service_quality_score,
                "ambiance_score": ambiance_score,
                # Competition
                "competitors_nearby": competitors_nearby,
                # Financial (monthly)
                "rent_monthly": rent_monthly,
                "staff_salary_monthly": staff_salary_monthly,
                "marketing_budget": marketing_budget,
                "utility_cost": utility_cost,
                "food_cost_pct": food_cost_pct,
                # Revenue and profit
                "monthly_revenue": monthly_revenue,
                "monthly_profit": monthly_profit,
                "profit_margin": profit_margin,
                # Classification
                "risk_level": risk_level,
                "success_score": success_score,
            }

            data.append(record)

            if (i + 1) % 1000 == 0:
                print(f"  Generated {i + 1}/{self.n_samples} records...")

        df = pd.DataFrame(data)
        print("✓ Data generation complete!")
        print(f"  Shape: {df.shape}")
        print(
            f"  Profit margin range: {df['profit_margin'].min():.2f}% to {df['profit_margin'].max():.2f}%"
        )

        return df

    def _calculate_rent(self, city, capacity, location_type):
        """Calculate realistic monthly rent based on city, capacity and location"""
        # Base rent per seat
        base_rent_map = {
            "Mumbai": 2000,
            "New Delhi": 1800,
            "Bengaluru": 1600,
            "Chennai": 1200,
            "Kolkata": 1100,
            "Hyderabad": 1300,
            "Ahmedabad": 1000,
            "Pune": 1400,
            "Jaipur": 900,
        }
        base_rent = base_rent_map.get(city, 800)

        # Location multiplier
        location_multiplier = {
            "Mall": 1.5,
            "IT Park": 1.4,
            "Airport": 1.8,
            "Commercial": 1.3,
            "Tourist Spot": 1.4,
            "Highway": 1.1,
            "Market": 1.0,
            "Street": 0.9,
            "Residential": 0.8,
            "Railway Station": 1.2,
        }

        multiplier = location_multiplier.get(location_type, 1.0)
        rent = base_rent * capacity * multiplier * np.random.uniform(0.8, 1.2)

        return round(rent, 2)

    def _get_population_density(self, city):
        """Get relative population density for city"""
        high_density = ["Mumbai", "New Delhi", "Kolkata", "Chennai", "Bengaluru"]
        medium_density = ["Hyderabad", "Ahmedabad", "Pune", "Jaipur", "Lucknow"]

        if city in high_density:
            return np.random.uniform(8000, 15000)
        elif city in medium_density:
            return np.random.uniform(4000, 8000)
        else:
            return np.random.uniform(1000, 4000)

    def _calculate_foot_traffic(self, location_type, population_density):
        """Calculate foot traffic based on location and density"""
        traffic_factor = {
            "Mall": 1.5,
            "Market": 1.4,
            "Tourist Spot": 1.6,
            "Commercial": 1.3,
            "Street": 1.2,
            "IT Park": 1.1,
            "Railway Station": 1.7,
            "Airport": 1.4,
            "Highway": 0.9,
            "Residential": 0.8,
        }

        factor = traffic_factor.get(location_type, 1.0)
        traffic = population_density * factor * np.random.uniform(0.1, 0.3)

        return round(traffic, 2)


def generate_dataset(output_path="data/restaurant_data_10k.csv", n_samples=10000):
    """
    Generate and save restaurant dataset

    Args:
        output_path: Path to save CSV file
        n_samples: Number of samples to generate

    Returns:
        pandas.DataFrame: Generated data
    """
    generator = RestaurantDataGenerator(n_samples=n_samples)
    df = generator.generate_data()

    # Save to CSV
    df.to_csv(output_path, index=False)
    print(f"✓ Dataset saved to {output_path}")

    # Display summary statistics
    print("\n" + "=" * 60)
    print("DATASET SUMMARY")
    print("=" * 60)
    print(f"Total records: {len(df)}")
    print(f"Cities covered: {df['city'].nunique()}")
    print(f"Cuisine types: {df['cuisine_type'].nunique()}")
    print(f"\nProfit Distribution:")
    print(
        f"  Profitable (>5%): {(df['profit_margin'] > 5).sum()} ({(df['profit_margin'] > 5).mean()*100:.1f}%)"
    )
    print(f"  Break-even (0-5%): {((df['profit_margin'] >= 0) & (df['profit_margin'] <= 5)).sum()}")
    print(f"  Loss-making (<0%): {(df['profit_margin'] < 0).sum()}")
    print(f"\nRisk Level Distribution:")
    print(df["risk_level"].value_counts())
    print("=" * 60)

    return df


if __name__ == "__main__":
    # Generate dataset
    df = generate_dataset(n_samples=10000)
