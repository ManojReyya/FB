"""
Machine Learning Module for FBAIS
Handles data generation, model training, and prediction pipeline
"""
