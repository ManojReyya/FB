"""
Customer Persona Synthetic Data Generator
Generates realistic training data for customer persona ML model
Similar to machine_learning/data_generator.py pattern
"""

import random
import numpy as np
import pandas as pd
import os
import sys
from datetime import datetime

# Add features folder to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "features"))
from personas import CustomerPersona


class CustomerDataGenerator:
    """Generate realistic synthetic customer data for Indian food business"""

    def __init__(self, random_seed=42):
        self.random_seed = random_seed
        random.seed(random_seed)
        np.random.seed(random_seed)
        self.personas = list(CustomerPersona.PERSONAS.keys())

    def generate_time(self, persona_key):
        """Generate realistic time with normal distribution around peak hours"""
        peak_times = CustomerPersona.PERSONAS[persona_key]["peak_times"]

        # Extract peak hour from first valid time range
        peak_hour = 12  # Default noon
        for peak_time in peak_times:
            if "-" in peak_time and ":" in peak_time:
                try:
                    peak_hour = int(peak_time.split("-")[0].split(":")[0])
                    break
                except:
                    continue

        # Add randomness with normal distribution (σ=2 hours)
        hour = int(np.random.normal(peak_hour, 2.0))
        hour = max(0, min(23, hour))  # Clamp to 0-23

        return hour

    def get_budget_for_persona(self, persona_key):
        """Get realistic budget distribution for each persona"""
        distributions = {
            "street_food": {"low": 0.75, "medium": 0.20, "high": 0.05},
            "fast_casual": {"low": 0.15, "medium": 0.70, "high": 0.15},
            "fine_dining": {"low": 0.02, "medium": 0.18, "high": 0.80},
            "cloud_kitchen": {"low": 0.20, "medium": 0.65, "high": 0.15},
            "regional_specialty": {"low": 0.10, "medium": 0.60, "high": 0.30},
            "catering_events": {"low": 0.02, "medium": 0.23, "high": 0.75},
            "health_organic": {"low": 0.05, "medium": 0.50, "high": 0.45},
        }

        dist = distributions.get(persona_key, {"low": 0.33, "medium": 0.34, "high": 0.33})
        return np.random.choice(
            ["low", "medium", "high"], p=[dist["low"], dist["medium"], dist["high"]]
        )

    def get_food_type_for_persona(self, persona_key):
        """Map persona to food type preference"""
        mappings = {
            "street_food": "street_food",
            "fast_casual": "dine_in",
            "fine_dining": "dine_in",
            "cloud_kitchen": "home_delivery",
            "regional_specialty": "dine_in",
            "catering_events": "catering",
            "health_organic": "health_conscious",
        }
        return mappings.get(persona_key, "dine_in")

    def get_occasion_for_budget(self, budget, persona_key):
        """Realistic occasion based on budget and persona"""
        if persona_key == "catering_events":
            return np.random.choice(["event", "celebration"], p=[0.80, 0.20])
        elif persona_key == "fine_dining":
            return np.random.choice(
                ["celebration", "casual_outing", "daily_meal"], p=[0.50, 0.35, 0.15]
            )
        elif budget == "low":
            return np.random.choice(["daily_meal", "casual_outing"], p=[0.75, 0.25])
        elif budget == "high":
            return np.random.choice(
                ["celebration", "casual_outing", "daily_meal", "event"], p=[0.35, 0.30, 0.25, 0.10]
            )
        else:  # medium
            return np.random.choice(
                ["daily_meal", "casual_outing", "celebration"], p=[0.60, 0.30, 0.10]
            )

    def get_customer_type_for_persona(self, persona_key):
        """Realistic customer type for persona"""
        distributions = {
            "street_food": {
                "student": 0.60,
                "working_professional": 0.30,
                "family": 0.08,
                "food_enthusiast": 0.02,
            },
            "fast_casual": {
                "family": 0.45,
                "working_professional": 0.35,
                "student": 0.15,
                "food_enthusiast": 0.05,
            },
            "fine_dining": {
                "food_enthusiast": 0.40,
                "working_professional": 0.35,
                "family": 0.20,
                "student": 0.05,
            },
            "cloud_kitchen": {
                "working_professional": 0.70,
                "student": 0.20,
                "family": 0.08,
                "food_enthusiast": 0.02,
            },
            "regional_specialty": {
                "food_enthusiast": 0.50,
                "family": 0.30,
                "working_professional": 0.15,
                "student": 0.05,
            },
            "catering_events": {
                "event_planner": 0.75,
                "family": 0.20,
                "working_professional": 0.05,
            },
            "health_organic": {
                "working_professional": 0.60,
                "food_enthusiast": 0.25,
                "student": 0.10,
                "family": 0.05,
            },
        }

        dist = distributions.get(
            persona_key,
            {
                "student": 0.25,
                "working_professional": 0.25,
                "family": 0.25,
                "food_enthusiast": 0.25,
            },
        )

        types = list(dist.keys())
        probs = list(dist.values())
        return np.random.choice(types, p=probs)

    def get_delivery_preference(self, food_type, customer_type):
        """Realistic delivery preference"""
        if food_type == "home_delivery":
            return "app_delivery"
        elif food_type == "street_food":
            return "self_pickup"
        elif food_type in ["catering", "dine_in"]:
            return "no_delivery"
        elif food_type == "health_conscious":
            return np.random.choice(["app_delivery", "self_pickup"], p=[0.70, 0.30])
        else:
            return np.random.choice(
                ["no_delivery", "app_delivery", "self_pickup"], p=[0.50, 0.35, 0.15]
            )

    def get_payment_method(self, budget, customer_type):
        """Realistic payment method"""
        if budget == "low":
            return np.random.choice(["cash", "upi", "paytm", "card"], p=[0.50, 0.35, 0.10, 0.05])
        elif budget == "high":
            return np.random.choice(
                ["card", "upi", "online_transfer", "cash"], p=[0.45, 0.35, 0.15, 0.05]
            )
        else:  # medium
            return np.random.choice(["upi", "cash", "card", "paytm"], p=[0.45, 0.30, 0.20, 0.05])

    def generate_sample(self, persona_key):
        """Generate single realistic sample for persona"""
        time = self.generate_time(persona_key)
        budget = self.get_budget_for_persona(persona_key)
        food_type = self.get_food_type_for_persona(persona_key)
        occasion = self.get_occasion_for_budget(budget, persona_key)
        customer_type = self.get_customer_type_for_persona(persona_key)
        delivery_pref = self.get_delivery_preference(food_type, customer_type)
        payment = self.get_payment_method(budget, customer_type)

        return {
            "time": time,
            "budget_level": budget,
            "food_type": food_type,
            "occasion": occasion,
            "customer_type": customer_type,
            "delivery_preference": delivery_pref,
            "payment_method": payment,
            "persona": persona_key,
        }

    def generate_dataset(self, samples_per_persona=1500):
        """
        Generate complete synthetic dataset
        Default: 1500 samples × 7 personas = 10,500 total samples
        """
        all_samples = []

        print(f"\n{'='*60}")
        print(f"Customer Persona Data Generator")
        print(f"{'='*60}\n")
        print(f"[*] Configuration:")
        print(f"    Samples per persona: {samples_per_persona}")
        print(f"    Total personas: {len(self.personas)}")
        print(f"    Total samples: {samples_per_persona * len(self.personas)}")
        print(f"    Random seed: {self.random_seed}\n")

        for i, persona_key in enumerate(self.personas, 1):
            persona_name = CustomerPersona.PERSONAS[persona_key]["name"]
            print(
                f"[{i}/{len(self.personas)}] Generating {samples_per_persona} samples for '{persona_name}'..."
            )

            for _ in range(samples_per_persona):
                sample = self.generate_sample(persona_key)
                all_samples.append(sample)

        df = pd.DataFrame(all_samples)

        print(f"\n{'='*60}")
        print(f"✓ Dataset Generated Successfully!")
        print(f"{'='*60}\n")
        print(f"Shape: {df.shape}")
        print(f"\nPersona Distribution:")
        print(df["persona"].value_counts().to_string())

        return df


def generate_training_data(output_path=None, samples_per_persona=1500):
    """
    Generate and save training data
    Main function to create synthetic dataset
    """
    if output_path is None:
        # Save in data folder outside machine_learning
        base_dir = os.path.dirname(__file__)
        data_dir = os.path.join(base_dir, "..", "data")
        os.makedirs(data_dir, exist_ok=True)
        output_path = os.path.join(data_dir, "customer_training_data.csv")

    print(f"\nOutput path: {output_path}\n")

    generator = CustomerDataGenerator(random_seed=42)
    df = generator.generate_dataset(samples_per_persona)

    # Save to CSV
    df.to_csv(output_path, index=False)

    print(f"\n✓ Dataset saved to: {output_path}")

    # Print detailed statistics
    print(f"\n{'='*60}")
    print(f"Dataset Statistics")
    print(f"{'='*60}\n")

    print(f"Total records: {len(df)}")
    print(f"\nBudget Level Distribution:")
    print(df["budget_level"].value_counts().to_string())
    print(f"\nCustomer Type Distribution:")
    print(df["customer_type"].value_counts().to_string())
    print(f"\nFood Type Distribution:")
    print(df["food_type"].value_counts().to_string())
    print(f"\nPayment Method Distribution:")
    print(df["payment_method"].value_counts().to_string())

    print(f"\n{'='*60}")
    print(f"Sample Records (first 5):")
    print(f"{'='*60}\n")
    print(df.head(5).to_string())

    return df, output_path


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("FBAIS - Customer Persona Data Generator")
    print("=" * 60)

    # Generate training data
    df, path = generate_training_data(samples_per_persona=1500)

    print(f"\n{'='*60}")
    print(f"✓ Data generation complete!")
    print(f"  Next step: Run customer_model_trainer.py to train the model")
    print(f"{'='*60}\n")
