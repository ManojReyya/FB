"""
Advanced Model Validation for FBAIS
Includes k-fold cross-validation, baseline comparison, and error analysis
"""

import pickle
import numpy as np
import pandas as pd
from sklearn.model_selection import cross_val_score, KFold
from sklearn.dummy import DummyRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy import stats


class ModelValidator:
    """Validate ML models with academic-grade metrics"""

    def __init__(
        self,
        model_path="machine_learning/profitability_models/profit_model.pkl",
        data_path="data/restaurant_data_10k.csv",
    ):
        self.model_path = model_path
        self.data_path = data_path
        self.model = None
        self.X = None
        self.y = None

    def load_model_and_data(self):
        """Load trained model and dataset"""
        print("Loading model and data...")

        with open(self.model_path, "rb") as f:
            self.model = pickle.load(f)

        df = pd.read_csv(self.data_path)

        with open("machine_learning/profitability_models/scaler.pkl", "rb") as f:
            scaler = pickle.load(f)
        with open("machine_learning/profitability_models/label_encoders.pkl", "rb") as f:
            encoders = pickle.load(f)
        with open("machine_learning/profitability_models/feature_columns.pkl", "rb") as f:
            feature_info = pickle.load(f)

        for col in feature_info["categorical_columns"]:
            if col in df.columns:
                df[f"{col}_encoded"] = encoders[col].transform(df[col])

        self.X = scaler.transform(df[feature_info["feature_columns"]])
        self.y = df["monthly_profit"].values
        self.df = df

        print(f"✓ Loaded: {len(self.y)} samples")

    def cross_validate(self, n_folds=5):
        """Perform k-fold cross-validation"""
        print(f"\n{'='*60}")
        print(f"K-FOLD CROSS-VALIDATION (k={n_folds})")
        print(f"{'='*60}")

        kfold = KFold(n_splits=n_folds, shuffle=True, random_state=42)

        scores = cross_val_score(self.model, self.X, self.y, cv=kfold, scoring="r2", n_jobs=-1)

        mean_score = scores.mean()
        std_score = scores.std()

        confidence = 0.95
        margin = std_score * stats.t.ppf((1 + confidence) / 2, n_folds - 1)

        print(f"\nR² Scores per fold:")
        for i, score in enumerate(scores, 1):
            print(f"  Fold {i}: {score:.4f}")

        print(f"\nStatistics:")
        print(f"  Mean R²: {mean_score:.4f}")
        print(f"  Std Dev: {std_score:.4f}")
        print(f"  95% CI:  [{mean_score - margin:.4f}, {mean_score + margin:.4f}]")

        return {
            "scores": scores,
            "mean": mean_score,
            "std": std_score,
            "confidence_interval": (mean_score - margin, mean_score + margin),
        }

    def baseline_comparison(self):
        """Compare model against baseline predictors"""
        print(f"\n{'='*60}")
        print("BASELINE COMPARISON")
        print(f"{'='*60}")

        y_pred = self.model.predict(self.X)

        model_r2 = r2_score(self.y, y_pred)
        model_mae = mean_absolute_error(self.y, y_pred)
        model_rmse = np.sqrt(mean_squared_error(self.y, y_pred))

        mean_baseline = DummyRegressor(strategy="mean")
        mean_baseline.fit(self.X, self.y)
        mean_pred = mean_baseline.predict(self.X)
        mean_r2 = r2_score(self.y, mean_pred)
        mean_mae = mean_absolute_error(self.y, mean_pred)

        median_baseline = DummyRegressor(strategy="median")
        median_baseline.fit(self.X, self.y)
        median_pred = median_baseline.predict(self.X)
        median_r2 = r2_score(self.y, median_pred)
        median_mae = mean_absolute_error(self.y, median_pred)

        print(f"\n{'Model':<25} {'R²':<12} {'MAE':<15} {'RMSE':<12}")
        print(f"{'-'*64}")
        print(
            f"{'Random Forest (Ours)':<25} {model_r2:<12.4f} {model_mae:<15.2f} {model_rmse:<12.2f}"
        )
        print(f"{'Mean Baseline':<25} {mean_r2:<12.4f} {mean_mae:<15.2f} {'-':<12}")
        print(f"{'Median Baseline':<25} {median_r2:<12.4f} {median_mae:<15.2f} {'-':<12}")

        improvement_vs_mean = ((model_r2 - mean_r2) / abs(mean_r2) * 100) if mean_r2 != 0 else 0
        improvement_vs_median = (
            ((model_r2 - median_r2) / abs(median_r2) * 100) if median_r2 != 0 else 0
        )

        print(f"\nImprovements:")
        print(f"  vs Mean Baseline:   {improvement_vs_mean:+.1f}%")
        print(f"  vs Median Baseline: {improvement_vs_median:+.1f}%")

        return {
            "model": {"r2": model_r2, "mae": model_mae, "rmse": model_rmse},
            "mean_baseline": {"r2": mean_r2, "mae": mean_mae},
            "median_baseline": {"r2": median_r2, "mae": median_mae},
        }

    def error_analysis(self):
        """Analyze prediction errors by category"""
        print(f"\n{'='*60}")
        print("ERROR ANALYSIS BY CATEGORY")
        print(f"{'='*60}")

        y_pred = self.model.predict(self.X)
        errors = np.abs(self.y - y_pred)

        self.df["predicted_profit"] = y_pred
        self.df["absolute_error"] = errors
        self.df["percentage_error"] = np.abs((self.y - y_pred) / (self.y + 1)) * 100

        print("\n1. ERROR BY CITY (Top 5)")
        print(f"{'-'*64}")
        city_errors = (
            self.df.groupby("city")
            .agg({"absolute_error": "mean", "percentage_error": "mean", "monthly_profit": "count"})
            .round(2)
        )
        city_errors.columns = ["MAE", "MAPE (%)", "Count"]
        city_errors = city_errors.sort_values("MAE", ascending=False).head(5)
        print(city_errors.to_string())

        print("\n2. ERROR BY CUISINE TYPE")
        print(f"{'-'*64}")
        cuisine_errors = (
            self.df.groupby("cuisine_type")
            .agg({"absolute_error": "mean", "percentage_error": "mean", "monthly_profit": "count"})
            .round(2)
        )
        cuisine_errors.columns = ["MAE", "MAPE (%)", "Count"]
        cuisine_errors = cuisine_errors.sort_values("MAE", ascending=False)
        print(cuisine_errors.to_string())

        print("\n3. ERROR BY PROFIT RANGE")
        print(f"{'-'*64}")
        self.df["profit_range"] = pd.cut(
            self.df["monthly_profit"],
            bins=[-np.inf, 0, 100000, 200000, np.inf],
            labels=["Loss", "Low Profit", "Medium Profit", "High Profit"],
        )

        range_errors = (
            self.df.groupby("profit_range")
            .agg(
                {
                    "absolute_error": "mean",
                    "percentage_error": "mean",
                    "monthly_profit": ["count", "mean"],
                }
            )
            .round(2)
        )
        range_errors.columns = ["MAE", "MAPE (%)", "Count", "Avg Profit"]
        print(range_errors.to_string())

        overall_mae = errors.mean()
        overall_rmse = np.sqrt(mean_squared_error(self.y, y_pred))
        overall_mape = np.mean(np.abs((self.y - y_pred) / (self.y + 1)) * 100)

        print(f"\n4. OVERALL ERROR METRICS")
        print(f"{'-'*64}")
        print(f"  Mean Absolute Error (MAE):  ₹{overall_mae:,.2f}")
        print(f"  Root Mean Squared Error:    ₹{overall_rmse:,.2f}")
        print(f"  Mean Absolute % Error:      {overall_mape:.2f}%")

        return {
            "overall": {"mae": overall_mae, "rmse": overall_rmse, "mape": overall_mape},
            "by_city": city_errors.to_dict(),
            "by_cuisine": cuisine_errors.to_dict(),
            "by_range": range_errors.to_dict(),
        }

    def run_full_validation(self):
        """Execute complete validation suite"""
        print("\n" + "=" * 60)
        print("FBAIS MODEL VALIDATION REPORT")
        print("=" * 60)

        self.load_model_and_data()

        cv_results = self.cross_validate(n_folds=5)
        baseline_results = self.baseline_comparison()
        error_results = self.error_analysis()

        print("\n" + "=" * 60)
        print("VALIDATION COMPLETE")
        print("=" * 60)
        print("\nKey Findings:")
        print(f"  • Cross-validation R²: {cv_results['mean']:.4f} ± {cv_results['std']:.4f}")
        print(f"  • Model R²: {baseline_results['model']['r2']:.4f}")
        print(f"  • Overall MAE: ₹{error_results['overall']['mae']:,.2f}")
        print(f"  • Overall MAPE: {error_results['overall']['mape']:.2f}%")

        return {
            "cross_validation": cv_results,
            "baseline_comparison": baseline_results,
            "error_analysis": error_results,
        }


if __name__ == "__main__":
    validator = ModelValidator()
    results = validator.run_full_validation()
