"""
Customer Persona Predictor
Uses trained ML model to predict customer personas
Follows machine_learning/restaurant_prediction_pipeline.py pattern
"""

import pickle
import numpy as np
import json
import os
import sys

# Add features folder to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "features"))
from personas import CustomerPersona


class CustomerPersonaPredictor:
    """
    Customer persona predictor with ML model + rule-based fallback
    Automatically loads trained model if available
    """

    def __init__(self, models_dir=None):
        """Initialize predictor and load trained model if available"""

        if models_dir is None:
            base_dir = os.path.dirname(__file__)
            models_dir = os.path.join(base_dir, "customer_models")

        self.models_dir = models_dir
        self.model = None
        self.label_encoders = None
        self.feature_names = None
        self.metadata = None
        self.model_available = False

        # Try to load model
        self._load_model()

    def _load_model(self):
        """Load trained model and artifacts"""
        try:
            model_path = os.path.join(self.models_dir, "customer_classifier.pkl")
            encoders_path = os.path.join(self.models_dir, "customer_encoders.pkl")
            features_path = os.path.join(self.models_dir, "customer_features.pkl")
            metadata_path = os.path.join(self.models_dir, "customer_metadata.json")

            print("[*] Loading customer persona ML model...")

            # Load model
            if os.path.exists(model_path):
                with open(model_path, "rb") as f:
                    self.model = pickle.load(f)
                print(f"  ✓ Model loaded")
            else:
                print(f"  ✗ Model not found at {model_path}")
                return

            # Load encoders
            if os.path.exists(encoders_path):
                with open(encoders_path, "rb") as f:
                    self.label_encoders = pickle.load(f)
                print(f"  ✓ Encoders loaded")
            else:
                print(f"  ✗ Encoders not found")
                return

            # Load features
            if os.path.exists(features_path):
                with open(features_path, "rb") as f:
                    self.feature_names = pickle.load(f)
                print(f"  ✓ Features loaded")
            else:
                print(f"  ✗ Features not found")
                return

            # Load metadata
            if os.path.exists(metadata_path):
                with open(metadata_path, "r") as f:
                    self.metadata = json.load(f)
                print(f"  ✓ Metadata loaded")
                print(f"  ✓ Model accuracy: {self.metadata.get('accuracy', 0)*100:.2f}%")

            self.model_available = True
            print("✓ ML model ready for predictions")

        except Exception as e:
            print(f"✗ Error loading model: {e}")
            self.model_available = False

    def _prepare_features(self, criteria):
        """Prepare and encode features for ML model prediction"""
        if not self.model_available:
            return None

        try:
            features_dict = {}

            for feature in self.feature_names:
                if feature == "time":
                    features_dict[feature] = criteria.get("time", 12)
                elif feature in criteria:
                    value = criteria[feature]
                    encoder = self.label_encoders.get(feature)

                    if encoder:
                        try:
                            encoded_value = encoder.transform([value])[0]
                            features_dict[feature] = encoded_value
                        except ValueError:
                            # Value not in training set, use default
                            features_dict[feature] = 0
                    else:
                        features_dict[feature] = 0
                else:
                    features_dict[feature] = 0

            # Create feature array in correct order
            X = np.array([[features_dict[f] for f in self.feature_names]])
            return X

        except Exception as e:
            print(f"Error preparing features: {e}")
            return None

    def predict_ml(self, criteria):
        """
        Predict persona using ML model
        Returns: persona_key, confidence, probabilities
        """
        if not self.model_available:
            return None, 0, None

        try:
            X = self._prepare_features(criteria)
            if X is None:
                return None, 0, None

            # Get prediction and probabilities
            persona_encoded = self.model.predict(X)[0]
            probabilities = self.model.predict_proba(X)[0]

            # Decode persona
            persona_encoder = self.label_encoders.get("persona")
            if persona_encoder:
                persona_key = persona_encoder.inverse_transform([persona_encoded])[0]
            else:
                return None, 0, None

            # Get confidence (max probability)
            confidence = float(np.max(probabilities))

            # Get all predictions with probabilities
            persona_probs = {
                persona_encoder.inverse_transform([i])[0]: float(prob)
                for i, prob in enumerate(probabilities)
            }

            return persona_key, confidence, persona_probs

        except Exception as e:
            print(f"Error in ML prediction: {e}")
            return None, 0, None

    def predict_rule_based(self, criteria):
        """
        Predict using rule-based logic (fallback)
        """
        return CustomerPersona.identify_persona(criteria)

    def predict(self, criteria, ml_threshold=0.70):
        """
        Hybrid prediction: Use ML model if confident, fallback to rule-based

        Args:
            criteria: Customer criteria dict
            ml_threshold: Minimum confidence to trust ML model (default: 0.70)

        Returns:
            Full prediction result with metadata
        """

        # Get ML prediction
        ml_persona, ml_confidence, ml_probs = self.predict_ml(criteria)

        # Get rule-based prediction
        rule_result = self.predict_rule_based(criteria)

        # Decide which to use
        if ml_persona and ml_confidence >= ml_threshold:
            # Use ML prediction
            persona_data = CustomerPersona.PERSONAS[ml_persona]
            result = {
                "persona_key": ml_persona,
                "persona_name": persona_data["name"],
                "confidence": min(100, ml_confidence * 100),
                "characteristics": persona_data["characteristics"],
                "cuisine_types": persona_data.get("cuisine_types", []),
                "peak_times": persona_data["peak_times"],
                "products": persona_data["products"],
                "avg_spending": persona_data["avg_spending"],
                "payment_methods": persona_data.get("payment_methods", []),
                "price_strategy": persona_data["price_strategy"],
                "marketing_strategies": persona_data["marketing"],
                "detection_reasons": [f"ML Model (confidence: {ml_confidence*100:.1f}%)"],
                "model_used": "ML_MODEL",
                "all_predictions": ml_probs,
                "ml_confidence": ml_confidence * 100,
                "model_accuracy": self.metadata.get("accuracy", 0) * 100 if self.metadata else 0,
            }
        else:
            # Use rule-based (fallback)
            result = rule_result.copy()
            result["model_used"] = "RULE_BASED"
            result["all_predictions"] = ml_probs if ml_probs else None
            result["ml_confidence"] = ml_confidence * 100 if ml_confidence else 0
            result["model_accuracy"] = 0

        return result

    def explain_prediction(self, criteria):
        """
        Explain why a specific prediction was made
        Shows both ML and rule-based results
        """
        ml_persona, ml_confidence, ml_probs = self.predict_ml(criteria)
        rule_result = self.predict_rule_based(criteria)

        explanation = {
            "ml_prediction": {
                "available": self.model_available,
                "persona": ml_persona,
                "confidence": ml_confidence * 100 if ml_confidence else 0,
                "top_3_predictions": (
                    sorted(ml_probs.items(), key=lambda x: x[1], reverse=True)[:3]
                    if ml_probs
                    else []
                ),
            },
            "rule_based_prediction": {
                "persona": rule_result.get("persona_key"),
                "confidence": rule_result.get("confidence"),
                "reasons": rule_result.get("detection_reasons", []),
            },
            "model_status": {
                "available": self.model_available,
                "accuracy": self.metadata.get("accuracy", 0) * 100 if self.metadata else 0,
                "trained_date": self.metadata.get("training_date") if self.metadata else None,
            },
        }

        return explanation

    def get_model_info(self):
        """Get information about the loaded model"""
        if not self.model_available:
            return {
                "status": "NOT_AVAILABLE",
                "message": "ML model not trained. Using rule-based predictions.",
                "recommendation": "Run customer_data_generator.py and customer_model_trainer.py to train model.",
            }

        return {
            "status": "AVAILABLE",
            "model_type": self.metadata.get("model_type"),
            "accuracy": self.metadata.get("accuracy", 0) * 100,
            "f1_score": self.metadata.get("f1_score", 0) * 100,
            "n_classes": self.metadata.get("n_classes"),
            "classes": self.metadata.get("classes"),
            "training_date": self.metadata.get("training_date"),
            "train_samples": self.metadata.get("train_samples"),
            "test_samples": self.metadata.get("test_samples"),
        }


# Global predictor instance
_predictor = None


def get_predictor():
    """Get or create global predictor instance"""
    global _predictor
    if _predictor is None:
        _predictor = CustomerPersonaPredictor()
    return _predictor


def predict_persona(criteria, ml_threshold=0.70):
    """
    Convenience function to predict customer persona

    Args:
        criteria: dict with customer attributes
        ml_threshold: confidence threshold for ML model

    Returns:
        Prediction result dict
    """
    predictor = get_predictor()
    return predictor.predict(criteria, ml_threshold)
