"""
Waste Tracker Feature
API routes for food waste tracking and analytics
"""

from flask import Blueprint, render_template, request, jsonify
from datetime import datetime, timedelta
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

waste_bp = Blueprint("waste", __name__)


def get_db():
    """Get database connection from main app"""
    from app import get_db as app_get_db

    return app_get_db()


@waste_bp.route("/waste-tracker")
def waste_tracker():
    """Render waste tracker page"""
    return render_template("waste.html")


@waste_bp.route("/api/waste", methods=["GET"])
def get_waste():
    """Get all waste entries for current user"""
    from flask import session

    if "user_id" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM waste_entries WHERE user_id = ? ORDER BY date_recorded DESC",
        (session["user_id"],),
    )
    entries = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(entries)


@waste_bp.route("/api/waste", methods=["POST"])
def add_waste():
    """Add new waste entry"""
    from flask import session

    if "user_id" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    data = request.json

    try:
        conn = get_db()
        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO waste_entries
            (user_id, item_name, category, quantity, unit, date_recorded, cost_value, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
            (
                session["user_id"],
                data["itemName"],
                data["category"],
                float(data["quantity"]),
                data["unit"],
                data["dateRecorded"],
                float(data["costValue"]),
                data.get("notes", ""),
            ),
        )

        conn.commit()
        entry_id = cursor.lastrowid
        conn.close()

        return jsonify({"success": True, "id": entry_id}), 201
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@waste_bp.route("/api/waste/<int:waste_id>", methods=["DELETE"])
def delete_waste(waste_id):
    """Delete waste entry"""
    from flask import session

    if "user_id" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    try:
        conn = get_db()
        cursor = conn.cursor()
        # Only allow deleting own entries
        cursor.execute(
            "DELETE FROM waste_entries WHERE id = ? AND user_id = ?", (waste_id, session["user_id"])
        )
        conn.commit()
        conn.close()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@waste_bp.route("/api/analytics", methods=["GET"])
def get_analytics():
    """Get waste analytics and statistics for current user"""
    from flask import session

    if "user_id" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM waste_entries WHERE user_id = ?", (session["user_id"],))
    entries = [dict(row) for row in cursor.fetchall()]
    conn.close()

    if not entries:
        return jsonify(
            {
                "totalWasteCost": 0,
                "totalQuantity": 0,
                "entryCount": 0,
                "categoryBreakdown": {},
                "weeklyCost": 0,
                "dailyBreakdown": {},
                "averageItemCost": 0,
            }
        )

    # Calculate totals
    total_cost = sum(e["cost_value"] for e in entries)
    total_qty = sum(e["quantity"] for e in entries)

    # Category breakdown
    categories = {}
    for entry in entries:
        cat = entry["category"]
        if cat not in categories:
            categories[cat] = {"quantity": 0, "cost": 0, "items": 0}
        categories[cat]["quantity"] += entry["quantity"]
        categories[cat]["cost"] += entry["cost_value"]
        categories[cat]["items"] += 1

    # Last 7 days
    week_ago = (datetime.now().date() - timedelta(days=7)).isoformat()
    recent = [e for e in entries if e["date_recorded"] >= week_ago]
    weekly_cost = sum(e["cost_value"] for e in recent)

    # Daily breakdown
    daily = {}
    for entry in recent:
        date = entry["date_recorded"]
        if date not in daily:
            daily[date] = {"cost": 0, "quantity": 0}
        daily[date]["cost"] += entry["cost_value"]
        daily[date]["quantity"] += entry["quantity"]

    return jsonify(
        {
            "totalWasteCost": round(total_cost, 2),
            "totalQuantity": round(total_qty, 2),
            "entryCount": len(entries),
            "categoryBreakdown": categories,
            "weeklyCost": round(weekly_cost, 2),
            "dailyBreakdown": daily,
            "averageItemCost": round(total_cost / len(entries), 2),
        }
    )


@waste_bp.route("/api/categories", methods=["GET"])
def get_categories():
    """Get waste categories"""
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM waste_categories")
    categories = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(categories)


@waste_bp.route("/api/export", methods=["GET"])
def export_data():
    """Export waste data for current user"""
    from flask import session

    if "user_id" not in session:
        return jsonify({"error": "Not authenticated"}), 401

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM waste_entries WHERE user_id = ? ORDER BY date_recorded DESC",
        (session["user_id"],),
    )
    entries = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(entries)
