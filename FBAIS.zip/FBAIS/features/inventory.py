"""
Inventory & Recipe Management
Recipe search, ingredient scaling, and recipe calculator
"""

from flask import Blueprint, jsonify, request
import pandas as pd
import re
from pathlib import Path

inventory_bp = Blueprint("inventory", __name__)
recipes_df = None


def inventory_init_recipes():
    """Load Indian recipes dataset"""
    global recipes_df
    try:
        csv_path = Path("data/IndianFoodDatasetCSV.csv")
        if csv_path.exists():
            recipes_df = pd.read_csv(csv_path)
            print(f"✓ Loaded {len(recipes_df)} recipes")
        else:
            print(f"✗ Recipe CSV not found: {csv_path}")
            recipes_df = None
    except Exception as e:
        print(f"✗ Recipe loading error: {e}")
        recipes_df = None


def scale_ingredient(ingredient, factor):
    """Scale ingredient quantity by factor"""
    ingredient = ingredient.strip()
    match = re.match(r"(\d+\.?\d*|\d+/\d+)\s*", ingredient)

    if match:
        qty_str = match.group(1)
        rest = ingredient[len(match.group(0)) :].strip()

        # Handle fractions
        if "/" in qty_str:
            parts = qty_str.split("/")
            qty = (float(parts[0]) / float(parts[1])) * factor
        else:
            qty = float(qty_str) * factor

        # Format output
        if qty == int(qty):
            return f"{int(qty)} {rest}"
        else:
            return f"{qty:.2f} {rest}".rstrip("0").rstrip(".")

    return ingredient


def scale_ingredients(ingredients, original_servings, target_servings):
    """Scale all ingredients for new serving size"""
    factor = target_servings / original_servings if original_servings > 0 else 1
    return [scale_ingredient(ing, factor) for ing in ingredients]


# ===========================
# APIs
# ===========================


@inventory_bp.route("/api/recipes", methods=["GET"])
def get_recipes():
    """Get all recipe names"""
    if recipes_df is None:
        return jsonify({"error": "Recipes not loaded"}), 500

    try:
        recipes = recipes_df["RecipeName"].dropna().unique().tolist()
        return jsonify(sorted(recipes))
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@inventory_bp.route("/api/recipe-details/<recipe_name>", methods=["GET"])
def get_recipe_details(recipe_name):
    """Get recipe details"""
    if recipes_df is None:
        return jsonify({"error": "Recipes not loaded"}), 500

    try:
        recipe_data = recipes_df[recipes_df["RecipeName"] == recipe_name]
        if recipe_data.empty:
            return jsonify({"error": "Recipe not found"}), 404

        recipe = recipe_data.iloc[0]
        ingredients = [ing.strip() for ing in recipe["Ingredients"].split(",") if ing.strip()]

        return jsonify(
            {
                "recipeName": recipe["RecipeName"],
                "originalServings": int(recipe["Servings"]),
                "ingredients": ingredients,
                "prepTime": int(recipe["PrepTimeInMins"]),
                "cookTime": int(recipe["CookTimeInMins"]),
                "totalTime": int(recipe["TotalTimeInMins"]),
                "cuisine": recipe["Cuisine"],
                "course": recipe["Course"],
                "diet": recipe["Diet"],
            }
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@inventory_bp.route("/api/scale-ingredients", methods=["POST"])
def scale_ingredients_api():
    """Scale recipe ingredients"""
    data = request.json
    scaled = scale_ingredients(
        data.get("ingredients", []), data.get("originalServings", 1), data.get("targetServings", 1)
    )
    return jsonify({"scaledIngredients": scaled})


@inventory_bp.route("/api/recipe-stats", methods=["GET"])
def get_recipe_stats():
    """Get recipe dataset statistics"""
    if recipes_df is None:
        return jsonify({"error": "Recipes not loaded"}), 500

    try:
        return jsonify(
            {
                "total_recipes": len(recipes_df),
                "cuisines": recipes_df["Cuisine"].value_counts().to_dict(),
                "courses": recipes_df["Course"].value_counts().to_dict(),
                "diets": recipes_df["Diet"].value_counts().to_dict(),
                "avg_prep_time": round(recipes_df["PrepTimeInMins"].mean(), 1),
                "avg_cook_time": round(recipes_df["CookTimeInMins"].mean(), 1),
                "avg_servings": round(recipes_df["Servings"].mean(), 1),
            }
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500
