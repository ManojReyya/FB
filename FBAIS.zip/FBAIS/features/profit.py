"""
Profitability Prediction API
Provides endpoints for restaurant profit and risk prediction
"""

from flask import Blueprint, jsonify, request
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from machine_learning.restaurant_prediction_pipeline import (  # noqa: E402
    RestaurantProfitabilityPredictor,
)

profit_bp = Blueprint("profit", __name__)
predictor = None


def init_predictor():
    """Load ML models for predictions"""
    global predictor
    if predictor is None:
        try:
            predictor = RestaurantProfitabilityPredictor()
            print("✓ Profit predictor ready")
        except Exception as e:
            print(f"✗ Model loading failed: {e}")


# Indian state capitals for dropdown
INDIA_CAPITALS = [
    "Mumbai",
    "Bengaluru",
    "Chennai",
    "Kolkata",
    "Hyderabad",
    "Ahmedabad",
    "Pune",
    "Jaipur",
    "Lucknow",
    "Kanpur",
    "Nagpur",
    "Indore",
    "Bhopal",
    "Patna",
    "Vadodara",
    "Ludhiana",
    "Agra",
    "Nashik",
    "Faridabad",
    "Meerut",
    "Rajkot",
    "Varanasi",
    "Srinagar",
    "Aurangabad",
    "Dhanbad",
    "Amritsar",
    "Allahabad",
    "Ranchi",
    "Guwahati",
    "Chandigarh",
    "New Delhi",
    "Puducherry",
    "Port Blair",
    "Silvassa",
    "Daman",
    "Kavaratti",
]

CUISINES = [
    "North Indian",
    "South Indian",
    "Chinese",
    "Continental",
    "Fast Food",
    "Multi-Cuisine",
    "Cafe",
    "Bakery",
    "Street Food",
    "Regional",
    "Fusion",
    "Vegetarian",
]

LOCATION_TYPES = [
    "Mall",
    "Street",
    "Market",
    "IT Park",
    "Residential",
    "Commercial",
    "Highway",
    "Airport",
    "Railway Station",
    "Tourist Spot",
]


@profit_bp.route("/api/predict-profit", methods=["POST"])
def predict_profit():
    """Predict restaurant profitability"""
    if predictor is None:
        init_predictor()
        if predictor is None:
            return jsonify({"success": False, "error": "Models not available"}), 500

    try:
        data = request.json
        input_data = {
            "city": data.get("city"),
            "location_type": data.get("location_type"),
            "cuisine_type": data.get("cuisine_type"),
            "seating_capacity": int(data.get("seating_capacity", 50)),
            "avg_table_size": float(data.get("avg_table_size", 4)),
            "parking_available": int(data.get("parking_available", 0)),
            "home_delivery": int(data.get("home_delivery", 0)),
            "operating_hours": float(data.get("operating_hours", 10)),
            "days_open_per_week": int(data.get("days_open_per_week", 7)),
            "years_in_business": float(data.get("years_in_business", 1)),
            "avg_daily_customers": int(data.get("avg_daily_customers", 100)),
            "customer_rating": float(data.get("customer_rating", 4.0)),
            "online_orders_pct": float(data.get("online_orders_pct", 20)),
            "avg_order_value": float(data.get("avg_order_value", 400)),
            "staff_count": int(data.get("staff_count", 10)),
            "chef_experience_years": float(data.get("chef_experience_years", 5)),
            "food_quality_score": float(data.get("food_quality_score", 7.5)),
            "service_quality_score": float(data.get("service_quality_score", 7.5)),
            "ambiance_score": float(data.get("ambiance_score", 7.0)),
            "competitors_nearby": int(data.get("competitors_nearby", 5)),
            "population_density": float(data.get("population_density", 5000)),
            "foot_traffic": float(data.get("foot_traffic", 1500)),
            "rent_monthly": float(data.get("rent_monthly", 80000)),
            "staff_salary_monthly": float(data.get("staff_salary_monthly", 200000)),
            "marketing_budget": float(data.get("marketing_budget", 15000)),
            "utility_cost": float(data.get("utility_cost", 10000)),
            "food_cost_pct": float(data.get("food_cost_pct", 35)),
        }

        result = predictor.predict_all(input_data)
        return jsonify({"success": True, "prediction": result})

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@profit_bp.route("/api/restaurant-config", methods=["GET"])
def get_restaurant_config():
    """Get configuration options for form"""
    return jsonify(
        {"cities": sorted(INDIA_CAPITALS), "cuisines": CUISINES, "location_types": LOCATION_TYPES}
    )


@profit_bp.route("/api/feature-importance", methods=["GET"])
def get_feature_importance():
    """Get top features affecting profit"""
    if not predictor:
        return jsonify({"success": False, "error": "Models not loaded"}), 500

    try:
        importance = predictor.get_feature_importance(top_n=15)
        return jsonify({"success": True, "feature_importance": importance})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@profit_bp.route("/api/model-stats", methods=["GET"])
def get_model_stats():
    """Get model accuracy metrics"""
    if not predictor:
        return jsonify({"success": False, "error": "Models not loaded"}), 500

    try:
        import pickle

        with open("machine_learning/models/metrics.pkl", "rb") as f:
            metrics = pickle.load(f)

        return jsonify(
            {
                "success": True,
                "metrics": {
                    "profit_model": {
                        "r2_score": round(metrics["profit_model"]["test_r2"], 4),
                        "accuracy": f"{round(metrics['profit_model']['test_r2'] * 100, 1)}%",
                    },
                    "risk_model": {
                        "accuracy": f"{round(metrics['risk_model']['test_accuracy'] * 100, 1)}%"
                    },
                },
            }
        )
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


init_predictor()
