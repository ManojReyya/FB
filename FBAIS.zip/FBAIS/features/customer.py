"""
Customer Persona Analysis Feature
Identifies customer personas using ML models and rule-based logic
"""

from flask import Blueprint, jsonify, request

# Import from features folder
from personas import CustomerPersona
from machine_learning.customer_predictor import CustomerPersonaPredictor

# Create Blueprint
customer_bp = Blueprint("customer", __name__, url_prefix="/api/customer")

# Global predictor instance
predictor = None


def init_customer_predictor():
    """Initialize customer persona predictor"""
    global predictor
    try:
        print("\n[*] Initializing Customer Persona Predictor...")
        predictor = CustomerPersonaPredictor()

        if predictor.model_available:
            print("✓ Customer ML model loaded successfully")
            model_info = predictor.get_model_info()
            print(f"  Accuracy: {model_info['accuracy']:.2f}%")
        else:
            print("⚠ ML model not available, using rule-based predictions")
            print("  To train model: python features/customer_data_generator.py")
            print("                  python features/customer_model_trainer.py")

        return True
    except Exception as e:
        print(f"✗ Error initializing customer predictor: {e}")
        predictor = None
        return False


# ========================================
# ROUTES
# ========================================


@customer_bp.route("/identify", methods=["POST"])
def identify_persona():
    """
    Identify customer persona based on criteria

    Expected JSON body:
    {
        "time": 12,
        "budget_level": "low",
        "food_type": "street_food",
        "occasion": "daily_meal",
        "customer_type": "student",
        "delivery_preference": "self_pickup",
        "payment_method": "cash"
    }
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({"error": "No data provided"}), 400

        # Convert time to integer if provided
        if "time" in data:
            try:
                data["time"] = int(data["time"])
            except (ValueError, TypeError):
                data["time"] = 12  # Default to noon

        # Use predictor (ML + rule-based hybrid)
        if predictor:
            result = predictor.predict(data)
        else:
            # Fallback to pure rule-based
            result = CustomerPersona.identify_persona(data)

        return jsonify(result)

    except Exception as e:
        print(f"Error in identify_persona: {e}")
        return jsonify({"error": str(e)}), 500


@customer_bp.route("/personas", methods=["GET"])
def get_all_personas():
    """Get list of all available personas"""
    try:
        personas = CustomerPersona.get_all_personas()
        return jsonify({"personas": personas})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@customer_bp.route("/explain", methods=["POST"])
def explain_prediction():
    """
    Explain why a prediction was made
    Shows both ML and rule-based results
    """
    try:
        data = request.get_json()

        if not data:
            return jsonify({"error": "No data provided"}), 400

        if predictor:
            explanation = predictor.explain_prediction(data)
            return jsonify(explanation)
        else:
            return (
                jsonify(
                    {
                        "error": "Predictor not available",
                        "message": "Only rule-based prediction is available",
                    }
                ),
                503,
            )

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@customer_bp.route("/model-status", methods=["GET"])
def model_status():
    """Get ML model status and information"""
    try:
        if predictor:
            status = predictor.get_model_info()
        else:
            status = {"status": "NOT_INITIALIZED", "message": "Predictor not initialized"}

        return jsonify(status)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ========================================
# HELPER FUNCTIONS
# ========================================


def get_persona_recommendations(persona_key):
    """Get detailed recommendations for a specific persona"""
    if persona_key not in CustomerPersona.PERSONAS:
        return None

    persona = CustomerPersona.PERSONAS[persona_key]

    return {
        "name": persona["name"],
        "characteristics": persona["characteristics"],
        "peak_times": persona["peak_times"],
        "cuisine_types": persona.get("cuisine_types", []),
        "products": persona["products"],
        "avg_spending": persona["avg_spending"],
        "payment_methods": persona.get("payment_methods", []),
        "price_strategy": persona["price_strategy"],
        "marketing_strategies": persona["marketing"],
    }
